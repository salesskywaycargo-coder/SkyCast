export type WeatherUnit = 'metric' | 'imperial';

export type WeatherTheme =
  | 'clear-day'
  | 'clear-night'
  | 'cloudy'
  | 'rain'
  | 'snow'
  | 'thunder'
  | 'fog';

export type ActiveTab = 'overview' | 'hourly' | '7day' | 'airquality' | 'radar' | 'planner';

export interface LocationData {
  id: string;
  name: string;
  country: string;
  countryCode?: string;
  admin1?: string;
  latitude: number;
  longitude: number;
  timezone: string;
  isFavorite?: boolean;
}

export interface CurrentWeatherData {
  time: string;
  temperature: number;
  apparentTemperature: number;
  relativeHumidity: number;
  weatherCode: number;
  weatherDescription: string;
  weatherTheme: WeatherTheme;
  isDay: boolean;
  precipitation: number;
  cloudCover: number;
  pressureMsl: number;
  windSpeed: number;
  windDirection: number;
  windGusts: number;
  uvIndex: number;
  visibility: number;
  dewPoint: number;
}

export interface HourlyForecastItem {
  time: string;
  hour: string;
  timestamp: number;
  temperature: number;
  apparentTemperature: number;
  humidity: number;
  precipitationProbability: number;
  precipitation: number;
  weatherCode: number;
  weatherDescription: string;
  weatherTheme: WeatherTheme;
  windSpeed: number;
  windDirection: number;
  uvIndex: number;
  isDay: boolean;
}

export interface DailyForecastItem {
  date: string;
  dayName: string;
  shortDate: string;
  weatherCode: number;
  weatherDescription: string;
  weatherTheme: WeatherTheme;
  tempMax: number;
  tempMin: number;
  apparentTempMax: number;
  apparentTempMin: number;
  precipitationSum: number;
  precipitationProbabilityMax: number;
  uvIndexMax: number;
  sunrise: string;
  sunset: string;
  windSpeedMax: number;
  windDirectionDominant: number;
}

export interface AirQualityData {
  usAqi: number;
  europeanAqi: number;
  pm25: number;
  pm10: number;
  ozone: number;
  nitrogenDioxide: number;
  sulphurDioxide: number;
  carbonMonoxide: number;
  statusLabel: string;
  statusColor: string;
  statusBg: string;
  healthAdvice: string;
}

export interface WeatherData {
  location: LocationData;
  current: CurrentWeatherData;
  hourly: HourlyForecastItem[];
  daily: DailyForecastItem[];
  airQuality: AirQualityData;
  lastUpdated: string;
}
