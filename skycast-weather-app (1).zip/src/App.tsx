import React, { useState, useEffect, useCallback } from 'react';
import {
  ActiveTab,
  LocationData,
  WeatherData,
  WeatherUnit,
} from './types/weather';
import {
  DEFAULT_CITIES,
  fetchWeatherForCoordinates,
  getFallbackWeatherData,
} from './services/weatherApi';
import { AtmosphereBackground } from './components/AtmosphereBackground';
import { Header } from './components/Header';
import { HeroWeatherCard } from './components/HeroWeatherCard';
import { HourlyForecastView } from './components/HourlyForecastView';
import { DailyForecastView } from './components/DailyForecastView';
import { TelemetryGrid } from './components/TelemetryGrid';
import { AirQualitySection } from './components/AirQualitySection';
import { InteractiveRadarMap } from './components/InteractiveRadarMap';
import { SmartPlanner } from './components/SmartPlanner';
import { DownloadZipModal } from './components/DownloadZipModal';
import {
  Loader2,
  AlertCircle,
  MapPin,
  RefreshCw,
  Compass,
  ArrowRight,
  Download,
} from 'lucide-react';

const SAVED_LOCATIONS_KEY = 'skycast_saved_locations';
const PREFERRED_UNIT_KEY = 'skycast_unit_pref';
const LAST_LOCATION_KEY = 'skycast_last_location';

export default function App() {
  const [unit, setUnit] = useState<WeatherUnit>(() => {
    return (localStorage.getItem(PREFERRED_UNIT_KEY) as WeatherUnit) || 'metric';
  });

  const [savedLocations, setSavedLocations] = useState<LocationData[]>(() => {
    try {
      const stored = localStorage.getItem(SAVED_LOCATIONS_KEY);
      return stored ? JSON.parse(stored) : [DEFAULT_CITIES[0], DEFAULT_CITIES[1], DEFAULT_CITIES[2]];
    } catch {
      return [DEFAULT_CITIES[0], DEFAULT_CITIES[1]];
    }
  });

  const [currentLocation, setCurrentLocation] = useState<LocationData>(() => {
    try {
      const stored = localStorage.getItem(LAST_LOCATION_KEY);
      return stored ? JSON.parse(stored) : DEFAULT_CITIES[0]; // Tokyo default
    } catch {
      return DEFAULT_CITIES[0];
    }
  });

  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [activeTab, setActiveTab] = useState<ActiveTab>('overview');
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isLocating, setIsLocating] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);

  // Sync unit preference
  const handleToggleUnit = () => {
    const nextUnit: WeatherUnit = unit === 'metric' ? 'imperial' : 'metric';
    setUnit(nextUnit);
    localStorage.setItem(PREFERRED_UNIT_KEY, nextUnit);
  };

  // Sync saved locations
  const handleToggleSaveLocation = (loc: LocationData) => {
    setSavedLocations((prev) => {
      const exists = prev.some((item) => item.id === loc.id);
      let updated: LocationData[];
      if (exists) {
        updated = prev.filter((item) => item.id !== loc.id);
      } else {
        updated = [...prev, { ...loc, isFavorite: true }];
      }
      localStorage.setItem(SAVED_LOCATIONS_KEY, JSON.stringify(updated));
      return updated;
    });
  };

  const isCurrentSaved = savedLocations.some(
    (item) => item.id === currentLocation.id
  );

  // Load weather for location
  const loadWeatherData = useCallback(
    async (loc: LocationData, isManualRefresh = false) => {
      if (isManualRefresh) setIsRefreshing(true);
      else setIsLoading(true);
      setErrorMessage(null);

      try {
        const data = await fetchWeatherForCoordinates(loc);
        setWeather(data);
        localStorage.setItem(LAST_LOCATION_KEY, JSON.stringify(loc));
      } catch (err: any) {
        console.error('Weather load error:', err);
        setErrorMessage(
          'Failed to connect to weather data servers. Loaded cached telemetry.'
        );
        setWeather(getFallbackWeatherData(loc));
      } finally {
        setIsLoading(false);
        setIsRefreshing(false);
      }
    },
    []
  );

  // Initial and location change load
  useEffect(() => {
    loadWeatherData(currentLocation);
  }, [currentLocation, loadWeatherData]);

  // Geolocation handling
  const handleUseCurrentLocation = () => {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser.');
      return;
    }

    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude } = pos.coords;
        try {
          // Attempt reverse geocoding
          const res = await fetch(
            `https://geocoding-api.open-meteo.com/v1/search?name=${latitude.toFixed(
              2
            )},${longitude.toFixed(2)}&count=1&language=en&format=json`
          ).catch(() => null);

          let detectedName = 'Local Horizon';
          let detectedCountry = 'Detected Coordinates';

          if (res && res.ok) {
            const data = await res.json();
            if (data.results && data.results[0]) {
              detectedName = data.results[0].name;
              detectedCountry = data.results[0].country || 'Current Area';
            }
          }

          const detectedLoc: LocationData = {
            id: `gps-${latitude.toFixed(3)}-${longitude.toFixed(3)}`,
            name: detectedName,
            country: detectedCountry,
            latitude,
            longitude,
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'auto',
          };

          setCurrentLocation(detectedLoc);
        } catch {
          const fallbackLoc: LocationData = {
            id: `gps-${latitude.toFixed(2)}-${longitude.toFixed(2)}`,
            name: 'Local Station',
            country: 'Current Coordinates',
            latitude,
            longitude,
            timezone: 'auto',
          };
          setCurrentLocation(fallbackLoc);
        } finally {
          setIsLocating(false);
        }
      },
      (error) => {
        console.warn('Geolocation denied or unavailable:', error);
        setIsLocating(false);
        alert(
          'Location access was unavailable. You can search any city in the search bar.'
        );
      },
      { timeout: 10000, enableHighAccuracy: true }
    );
  };

  const handleSelectLocation = (loc: LocationData) => {
    setCurrentLocation(loc);
  };

  return (
    <div className="relative min-h-screen text-slate-100 flex flex-col font-sans">
      {/* Dynamic Ambient Atmospheric Canvas Backdrop */}
      {weather && (
        <AtmosphereBackground
          theme={weather.current.weatherTheme}
          isDay={weather.current.isDay}
        />
      )}

      {/* Primary Top Bar Contract */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentLocation={currentLocation}
        onSelectLocation={handleSelectLocation}
        unit={unit}
        onToggleUnit={handleToggleUnit}
        onUseCurrentLocation={handleUseCurrentLocation}
        isLocating={isLocating}
        savedLocations={savedLocations}
        onToggleSaveLocation={handleToggleSaveLocation}
        isCurrentSaved={isCurrentSaved}
        onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
      />

      {/* Quick City Strip (Explore Popular Metropolises) */}
      <div className="w-full border-b border-slate-850/60 bg-slate-950/40 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex items-center justify-between gap-4 overflow-x-auto no-scrollbar">
          <div className="flex items-center gap-2 text-xs text-slate-400 shrink-0">
            <Compass className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-semibold text-slate-300">Quick Stations:</span>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {DEFAULT_CITIES.map((city) => {
              const isSelected = city.id === currentLocation.id;
              return (
                <button
                  key={city.id}
                  onClick={() => handleSelectLocation(city)}
                  className={`px-2.5 py-1 text-xs rounded-md transition-all whitespace-nowrap ${
                    isSelected
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                  }`}
                >
                  {city.name}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-8">
        {isLoading && !weather ? (
          <div className="min-h-[60vh] flex flex-col items-center justify-center gap-4 text-center">
            <Loader2 className="w-10 h-10 text-cyan-400 animate-spin" />
            <div>
              <p className="text-lg font-bold text-white">
                Gathering Meteorological Telemetry...
              </p>
              <p className="text-xs text-slate-400 mt-1">
                Connecting to {currentLocation.name} observation coordinates
              </p>
            </div>
          </div>
        ) : weather ? (
          <div className="space-y-8 animate-in fade-in duration-300">
            {/* Error Notification if any */}
            {errorMessage && (
              <div className="p-3.5 rounded-xl bg-amber-950/30 border border-amber-800/50 flex items-center gap-3 text-xs text-amber-300">
                <AlertCircle className="w-4 h-4 shrink-0 text-amber-400" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* TAB: OVERVIEW */}
            {activeTab === 'overview' && (
              <div className="space-y-8">
                {/* 1. Hero Weather Card */}
                <HeroWeatherCard
                  weather={weather}
                  unit={unit}
                  onRefresh={() => loadWeatherData(currentLocation, true)}
                  isRefreshing={isRefreshing}
                />

                {/* 2. Hourly Timeline Preview */}
                <HourlyForecastView hourly={weather.hourly} unit={unit} />

                {/* 3. 7-Day Range Outlook */}
                <DailyForecastView
                  daily={weather.daily}
                  unit={unit}
                  currentTemp={weather.current.temperature}
                />

                {/* 4. Telemetry Instrumentation */}
                <TelemetryGrid
                  current={weather.current}
                  todayForecast={weather.daily[0] || null}
                  unit={unit}
                />

                {/* 5. Air Quality Spotlight */}
                <AirQualitySection
                  airQuality={weather.airQuality}
                  locationName={weather.location.name}
                />
              </div>
            )}

            {/* TAB: HOURLY */}
            {activeTab === 'hourly' && (
              <div className="space-y-6">
                <HourlyForecastView hourly={weather.hourly} unit={unit} />

                {/* Detailed 24-Hour Tabular Breakdown */}
                <div className="rounded-2xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 p-6 shadow-xl">
                  <h3 className="text-base font-bold text-white mb-4">
                    Complete 24-Hour Meteorological Log
                  </h3>
                  <div className="overflow-x-auto thin-scrollbar">
                    <table className="w-full text-left text-xs font-mono">
                      <thead>
                        <tr className="border-b border-slate-800 text-slate-400 font-sans">
                          <th className="py-3 px-3">Time</th>
                          <th className="py-3 px-3">Condition</th>
                          <th className="py-3 px-3">Temp</th>
                          <th className="py-3 px-3">Feels Like</th>
                          <th className="py-3 px-3">Precip Chance</th>
                          <th className="py-3 px-3">Humidity</th>
                          <th className="py-3 px-3">Wind</th>
                          <th className="py-3 px-3">UV Index</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60">
                        {weather.hourly.slice(0, 24).map((h) => (
                          <tr
                            key={h.time}
                            className="hover:bg-slate-800/30 transition-colors"
                          >
                            <td className="py-3 px-3 text-slate-200 font-semibold">
                              {h.hour}
                            </td>
                            <td className="py-3 px-3 text-slate-300 font-sans">
                              {h.weatherDescription}
                            </td>
                            <td className="py-3 px-3 text-white font-bold tabular-nums">
                              {Math.round(
                                unit === 'imperial'
                                  ? (h.temperature * 9) / 5 + 32
                                  : h.temperature
                              )}
                              °
                            </td>
                            <td className="py-3 px-3 text-slate-300 tabular-nums">
                              {Math.round(
                                unit === 'imperial'
                                  ? (h.apparentTemperature * 9) / 5 + 32
                                  : h.apparentTemperature
                              )}
                              °
                            </td>
                            <td className="py-3 px-3 text-cyan-300 tabular-nums">
                              {h.precipitationProbability}%
                            </td>
                            <td className="py-3 px-3 text-slate-300 tabular-nums">
                              {h.humidity}%
                            </td>
                            <td className="py-3 px-3 text-slate-300 tabular-nums">
                              {Math.round(
                                unit === 'imperial'
                                  ? h.windSpeed * 0.621371
                                  : h.windSpeed
                              )}{' '}
                              {unit === 'imperial' ? 'mph' : 'km/h'}
                            </td>
                            <td className="py-3 px-3 text-amber-300 tabular-nums">
                              {h.uvIndex}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: 7-DAY */}
            {activeTab === '7day' && (
              <div className="space-y-6">
                <DailyForecastView
                  daily={weather.daily}
                  unit={unit}
                  currentTemp={weather.current.temperature}
                />
              </div>
            )}

            {/* TAB: AIR QUALITY */}
            {activeTab === 'airquality' && (
              <div className="space-y-6">
                <AirQualitySection
                  airQuality={weather.airQuality}
                  locationName={weather.location.name}
                />
              </div>
            )}

            {/* TAB: RADAR */}
            {activeTab === 'radar' && (
              <div className="space-y-6">
                <InteractiveRadarMap location={weather.location} />
              </div>
            )}

            {/* TAB: PLANNER */}
            {activeTab === 'planner' && (
              <div className="space-y-6">
                <SmartPlanner weather={weather} unit={unit} />
              </div>
            )}
          </div>
        ) : null}
      </main>

      {/* Clean Typographic Anti-Slop Footer */}
      <footer className="mt-auto border-t border-slate-800/80 bg-slate-950/80 backdrop-blur-md py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-400 font-sans tracking-tight">
              SkyCast
            </span>
            <span aria-hidden="true">·</span>
            <span>Precision Atmospheric Meteorological Engine</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <span>Powered by Open-Meteo & RainViewer Doppler</span>
            <span aria-hidden="true">·</span>
            <button
              onClick={() => setIsDownloadModalOpen(true)}
              className="text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-1 cursor-pointer transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Project ZIP</span>
            </button>
          </div>
        </div>
      </footer>

      {/* Download Source Code Modal */}
      <DownloadZipModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
      />
    </div>
  );
}
