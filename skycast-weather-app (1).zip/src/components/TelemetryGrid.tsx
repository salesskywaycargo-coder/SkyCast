import React from 'react';
import {
  Wind,
  Sun,
  Droplets,
  Gauge,
  Eye,
  Cloud,
  Sunrise,
  Sunset,
  ShieldCheck,
  Compass,
  ArrowUpRight,
  TrendingDown,
  TrendingUp,
} from 'lucide-react';
import { CurrentWeatherData, DailyForecastItem, WeatherUnit } from '../types/weather';
import {
  formatPressure,
  formatSpeed,
  formatTemp,
  formatVisibility,
  getUVDescription,
  getWindDirectionCardinal,
} from '../services/weatherUtils';

interface TelemetryGridProps {
  current: CurrentWeatherData;
  todayForecast: DailyForecastItem | null;
  unit: WeatherUnit;
}

export const TelemetryGrid: React.FC<TelemetryGridProps> = ({
  current,
  todayForecast,
  unit,
}) => {
  const uvInfo = getUVDescription(current.uvIndex);

  // Calculate sun arc progress (0 to 1)
  const calculateSunProgress = () => {
    if (!todayForecast || !todayForecast.sunrise || !todayForecast.sunset)
      return 0.5;
    try {
      const now = new Date(current.time).getTime();
      const rise = new Date(todayForecast.sunrise).getTime();
      const set = new Date(todayForecast.sunset).getTime();
      if (now < rise) return 0;
      if (now > set) return 1;
      return (now - rise) / (set - rise);
    } catch {
      return 0.5;
    }
  };

  const sunProgress = calculateSunProgress();

  // Humidity comfort interpretation
  const getHumidityComfort = (rh: number) => {
    if (rh < 30) return 'Dry Atmosphere';
    if (rh <= 60) return 'Optimal Comfort';
    if (rh <= 75) return 'Moderate Humidity';
    return 'High Moisture / Muggy';
  };

  // Visibility interpretation
  const getVisibilityRating = (m: number) => {
    if (m >= 10000) return 'Exceptional Clarity';
    if (m >= 5000) return 'Standard Visibility';
    if (m >= 2000) return 'Hazy Conditions';
    return 'Dense Fog / Limited';
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
          <Gauge className="w-5 h-5 text-cyan-400" />
          <span>Atmospheric Instrumentation & Telemetry</span>
        </h2>
        <span className="text-xs text-slate-400 font-mono">Calibrated Real-Time</span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 1. Wind & Compass Bearing */}
        <div className="rounded-2xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 p-5 flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-3">
            <span className="flex items-center gap-1.5 font-medium">
              <Wind className="w-4 h-4 text-cyan-400" />
              Wind Dynamics
            </span>
            <span className="font-mono text-cyan-400">
              {getWindDirectionCardinal(current.windDirection)}
            </span>
          </div>

          <div className="flex items-center justify-between my-2">
            <div>
              <p className="text-3xl font-extrabold text-white font-mono tabular-nums">
                {formatSpeed(current.windSpeed, unit)}
              </p>
              <p className="text-xs text-slate-400 mt-1 font-mono">
                Gusts: {formatSpeed(current.windGusts, unit)}
              </p>
            </div>

            {/* Compass Dial */}
            <div className="relative w-14 h-14 rounded-full border border-slate-700 bg-slate-950 flex items-center justify-center shrink-0">
              <span className="absolute top-1 text-[9px] font-mono text-slate-500 font-bold">
                N
              </span>
              <span className="absolute bottom-1 text-[9px] font-mono text-slate-600">
                S
              </span>
              <div
                className="w-8 h-8 flex items-center justify-center transition-transform duration-700"
                style={{ transform: `rotate(${current.windDirection}deg)` }}
              >
                <div className="w-1 h-5 bg-gradient-to-t from-cyan-400 to-rose-500 rounded-full" />
              </div>
            </div>
          </div>

          <p className="text-[11px] text-slate-400 pt-3 border-t border-slate-800 font-mono">
            Vector Bearing: {current.windDirection}° Azimuth
          </p>
        </div>

        {/* 2. Solar Radiation & UV Index */}
        <div className="rounded-2xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 p-5 flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-3">
            <span className="flex items-center gap-1.5 font-medium">
              <Sun className="w-4 h-4 text-amber-400" />
              UV Radiation
            </span>
            <span className={`font-semibold ${uvInfo.color}`}>
              {uvInfo.label}
            </span>
          </div>

          <div className="my-2">
            <p className="text-3xl font-extrabold text-white font-mono tabular-nums">
              {current.uvIndex}{' '}
              <span className="text-sm font-sans font-normal text-slate-400">
                Index
              </span>
            </p>

            {/* UV Gauge Bar */}
            <div className="w-full h-2 bg-slate-800 rounded-full mt-3 overflow-hidden relative">
              <div
                className="h-full bg-gradient-to-r from-emerald-400 via-amber-400 via-orange-400 to-purple-500 rounded-full"
                style={{ width: `${Math.min(100, (current.uvIndex / 11) * 100)}%` }}
              />
            </div>
          </div>

          <p className="text-[11px] text-slate-400 pt-3 border-t border-slate-800 line-clamp-1">
            {uvInfo.advice}
          </p>
        </div>

        {/* 3. Humidity & Dew Point */}
        <div className="rounded-2xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 p-5 flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-3">
            <span className="flex items-center gap-1.5 font-medium">
              <Droplets className="w-4 h-4 text-sky-400" />
              Moisture & Humidity
            </span>
            <span className="text-slate-400">
              {getHumidityComfort(current.relativeHumidity)}
            </span>
          </div>

          <div className="my-2">
            <p className="text-3xl font-extrabold text-white font-mono tabular-nums">
              {current.relativeHumidity}%
            </p>
            <p className="text-xs text-slate-400 mt-1 font-mono">
              Dew Point: {formatTemp(current.dewPoint, unit)}
            </p>
          </div>

          <p className="text-[11px] text-slate-400 pt-3 border-t border-slate-800">
            {current.relativeHumidity > 70
              ? 'High atmospheric condensation risk'
              : 'Comfortable ambient vapor pressure'}
          </p>
        </div>

        {/* 4. Barometric Pressure */}
        <div className="rounded-2xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 p-5 flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-3">
            <span className="flex items-center gap-1.5 font-medium">
              <Gauge className="w-4 h-4 text-indigo-400" />
              Barometric Pressure
            </span>
            <span className="text-emerald-400 flex items-center gap-1 font-mono text-[11px]">
              <TrendingUp className="w-3.5 h-3.5" /> Steady
            </span>
          </div>

          <div className="my-2">
            <p className="text-3xl font-extrabold text-white font-mono tabular-nums">
              {formatPressure(current.pressureMsl, unit)}
            </p>
            <p className="text-xs text-slate-400 mt-1 font-mono">
              Mean Sea Level (MSL)
            </p>
          </div>

          <p className="text-[11px] text-slate-400 pt-3 border-t border-slate-800">
            {current.pressureMsl > 1013
              ? 'High pressure system (fair skies prevalent)'
              : 'Low pressure system (increased cloudiness)'}
          </p>
        </div>

        {/* 5. Visibility */}
        <div className="rounded-2xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 p-5 flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-3">
            <span className="flex items-center gap-1.5 font-medium">
              <Eye className="w-4 h-4 text-teal-400" />
              Optical Visibility
            </span>
            <span className="text-teal-400">
              {getVisibilityRating(current.visibility)}
            </span>
          </div>

          <div className="my-2">
            <p className="text-3xl font-extrabold text-white font-mono tabular-nums">
              {formatVisibility(current.visibility, unit)}
            </p>
            <p className="text-xs text-slate-400 mt-1 font-mono">
              Horizon Distance
            </p>
          </div>

          <p className="text-[11px] text-slate-400 pt-3 border-t border-slate-800">
            {current.visibility >= 10000
              ? 'Unobstructed visual flight conditions'
              : 'Slight atmospheric scattering observed'}
          </p>
        </div>

        {/* 6. Cloud Cover */}
        <div className="rounded-2xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 p-5 flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-3">
            <span className="flex items-center gap-1.5 font-medium">
              <Cloud className="w-4 h-4 text-sky-300" />
              Cloud Fraction
            </span>
            <span className="text-slate-400 font-mono">
              {current.cloudCover <= 20
                ? 'Clear'
                : current.cloudCover <= 60
                ? 'Scattered'
                : 'Overcast'}
            </span>
          </div>

          <div className="my-2">
            <p className="text-3xl font-extrabold text-white font-mono tabular-nums">
              {current.cloudCover}%
            </p>
            <div className="w-full h-2 bg-slate-800 rounded-full mt-3 overflow-hidden">
              <div
                className="h-full bg-sky-400 rounded-full transition-all duration-500"
                style={{ width: `${current.cloudCover}%` }}
              />
            </div>
          </div>

          <p className="text-[11px] text-slate-400 pt-3 border-t border-slate-800">
            Atmospheric solar insulation: {100 - current.cloudCover}%
          </p>
        </div>

        {/* 7. Solar Ephemeris & Sun Arc (spanning 2 cols on tablet/desktop) */}
        <div className="sm:col-span-2 rounded-2xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 p-5 flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span className="flex items-center gap-1.5 font-medium">
              <Sunrise className="w-4 h-4 text-amber-400" />
              Solar Ephemeris & Daylight Trajectory
            </span>
            <span className="font-mono text-slate-400">
              {current.isDay ? 'Daylight Phase' : 'Nocturnal Phase'}
            </span>
          </div>

          {/* SVG Sun Trajectory Arc */}
          <div className="relative w-full h-20 my-1 flex items-center justify-center">
            <svg viewBox="0 0 240 70" className="w-full h-full overflow-visible">
              {/* Horizon Line */}
              <line
                x1="20"
                y1="58"
                x2="220"
                y2="58"
                stroke="rgba(148, 163, 184, 0.25)"
                strokeDasharray="3 3"
              />

              {/* Parabolic Sun Trajectory */}
              <path
                d="M 30 58 Q 120 8 210 58"
                fill="none"
                stroke="rgba(251, 191, 36, 0.35)"
                strokeWidth="2"
                strokeDasharray="4 4"
              />

              {/* Traveled arc portion */}
              <path
                d="M 30 58 Q 120 8 210 58"
                fill="none"
                stroke="#f59e0b"
                strokeWidth="2.5"
                strokeDasharray="200"
                strokeDashoffset={200 - 200 * sunProgress}
              />

              {/* Dynamic Sun Position on Arc */}
              {(() => {
                // Parabolic parameterization: x in [30, 210], y = 58 - 50 * 4 * t * (1-t)
                const t = Math.max(0, Math.min(1, sunProgress));
                const sunX = 30 + 180 * t;
                const sunY = 58 - 50 * 4 * t * (1 - t);
                return (
                  <g transform={`translate(${sunX}, ${sunY})`}>
                    <circle r="6" fill="#f59e0b" />
                    <circle r="10" fill="#f59e0b" opacity="0.3" />
                  </g>
                );
              })()}
            </svg>
          </div>

          <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-800">
            <div className="flex items-center gap-2">
              <Sunrise className="w-4 h-4 text-amber-400" />
              <div>
                <p className="text-[10px] text-slate-500 uppercase font-mono">Sunrise</p>
                <p className="font-mono text-slate-200">
                  {todayForecast?.sunrise ? todayForecast.sunrise.slice(11, 16) : '06:15'}
                </p>
              </div>
            </div>

            <div className="text-center">
              <p className="text-[10px] text-slate-500 uppercase font-mono">Daylight</p>
              <p className="font-mono text-cyan-300">
                {current.isDay ? `${Math.round(sunProgress * 100)}% elapsed` : 'Night'}
              </p>
            </div>

            <div className="flex items-center gap-2 text-right">
              <div>
                <p className="text-[10px] text-slate-500 uppercase font-mono">Sunset</p>
                <p className="font-mono text-slate-200">
                  {todayForecast?.sunset ? todayForecast.sunset.slice(11, 16) : '18:45'}
                </p>
              </div>
              <Sunset className="w-4 h-4 text-rose-400" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
