import React, { useEffect, useRef } from 'react';
import { WeatherTheme } from '../types/weather';

interface AtmosphereBackgroundProps {
  theme: WeatherTheme;
  isDay: boolean;
}

export const AtmosphereBackground: React.FC<AtmosphereBackgroundProps> = ({
  theme,
  isDay,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    // Respect reduced motion
    const prefersReducedMotion = window.matchMedia(
      '(prefers-reduced-motion: reduce)'
    ).matches;

    // Particle setup based on theme
    interface Particle {
      x: number;
      y: number;
      speedY: number;
      speedX: number;
      size: number;
      opacity: number;
      pulse?: number;
      pulseSpeed?: number;
    }

    const particles: Particle[] = [];
    const count =
      theme === 'rain' || theme === 'thunder'
        ? 120
        : theme === 'snow'
        ? 80
        : theme === 'clear-night'
        ? 70
        : 25;

    for (let i = 0; i < count; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        speedY:
          theme === 'rain' || theme === 'thunder'
            ? 7 + Math.random() * 8
            : theme === 'snow'
            ? 0.8 + Math.random() * 1.5
            : (Math.random() - 0.5) * 0.2,
        speedX:
          theme === 'rain' || theme === 'thunder'
            ? -1.5 - Math.random() * 1.5
            : theme === 'snow'
            ? (Math.random() - 0.5) * 0.8
            : (Math.random() - 0.5) * 0.2,
        size:
          theme === 'rain' || theme === 'thunder'
            ? 1.2
            : theme === 'snow'
            ? 1.5 + Math.random() * 2.5
            : 1 + Math.random() * 1.5,
        opacity: Math.random() * 0.6 + 0.2,
        pulse: Math.random() * Math.PI,
        pulseSpeed: 0.02 + Math.random() * 0.03,
      });
    }

    let lightningTimer = 0;
    let lightningOpacity = 0;

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      if (prefersReducedMotion) {
        // Static gentle draw
        return;
      }

      if (theme === 'rain' || theme === 'thunder') {
        // Draw Rain
        ctx.strokeStyle = 'rgba(186, 230, 253, 0.45)';
        ctx.lineWidth = 1.2;

        for (const p of particles) {
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x + p.speedX * 2, p.y + p.speedY * 2.5);
          ctx.stroke();

          p.x += p.speedX;
          p.y += p.speedY;

          if (p.y > height) {
            p.y = -10;
            p.x = Math.random() * width;
          }
          if (p.x < 0) {
            p.x = width + 10;
          }
        }

        // Thunderstorm lightning flashes
        if (theme === 'thunder') {
          lightningTimer++;
          if (lightningTimer > 280 && Math.random() < 0.04) {
            lightningOpacity = 0.35 + Math.random() * 0.25;
            lightningTimer = 0;
          }
          if (lightningOpacity > 0) {
            ctx.fillStyle = `rgba(224, 242, 254, ${lightningOpacity})`;
            ctx.fillRect(0, 0, width, height);
            lightningOpacity -= 0.03;
          }
        }
      } else if (theme === 'snow') {
        // Draw Snowflakes
        for (const p of particles) {
          ctx.fillStyle = `rgba(255, 255, 255, ${p.opacity * 0.8})`;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();

          p.x += p.speedX + Math.sin(p.y * 0.01) * 0.4;
          p.y += p.speedY;

          if (p.y > height) {
            p.y = -5;
            p.x = Math.random() * width;
          }
        }
      } else if (theme === 'clear-night') {
        // Twinkling stars
        for (const p of particles) {
          if (p.pulse !== undefined && p.pulseSpeed !== undefined) {
            p.pulse += p.pulseSpeed;
            const currentOpacity = 0.2 + (Math.sin(p.pulse) + 1) * 0.35;
            ctx.fillStyle = `rgba(224, 242, 254, ${currentOpacity})`;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();
          }
        }
      } else if (theme === 'clear-day') {
        // Solar ambiance rays in top-right
        const sunX = width * 0.85;
        const sunY = height * 0.15;
        const gradient = ctx.createRadialGradient(
          sunX,
          sunY,
          10,
          sunX,
          sunY,
          Math.min(width, height) * 0.8
        );
        gradient.addColorStop(0, 'rgba(253, 224, 71, 0.15)');
        gradient.addColorStop(0.4, 'rgba(251, 146, 60, 0.05)');
        gradient.addColorStop(1, 'rgba(15, 23, 42, 0)');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, width, height);
      } else if (theme === 'cloudy' || theme === 'fog') {
        // Soft drifting atmospheric mist layers
        for (const p of particles) {
          p.x += p.speedX * 0.5;
          if (p.x > width + 50) p.x = -50;
          if (p.x < -50) p.x = width + 50;

          const grad = ctx.createRadialGradient(
            p.x,
            p.y,
            0,
            p.x,
            p.y,
            p.size * 35
          );
          grad.addColorStop(0, `rgba(148, 163, 184, ${p.opacity * 0.08})`);
          grad.addColorStop(1, 'rgba(148, 163, 184, 0)');
          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * 35, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [theme, isDay]);

  // Determine smooth background gradient classes
  const getGradientClass = () => {
    switch (theme) {
      case 'clear-day':
        return 'from-sky-900/60 via-slate-950 to-slate-950';
      case 'clear-night':
        return 'from-slate-950 via-indigo-950/40 to-slate-950';
      case 'cloudy':
        return 'from-slate-900/80 via-slate-950 to-slate-950';
      case 'rain':
        return 'from-cyan-950/60 via-slate-950 to-slate-950';
      case 'thunder':
        return 'from-purple-950/70 via-slate-950 to-slate-950';
      case 'snow':
        return 'from-sky-950/50 via-slate-950 to-slate-950';
      case 'fog':
        return 'from-zinc-900/70 via-slate-950 to-slate-950';
      default:
        return 'from-slate-900/70 via-slate-950 to-slate-950';
    }
  };

  return (
    <div className="fixed inset-0 pointer-events-none -z-10 overflow-hidden transition-colors duration-1000">
      {/* Base Gradient Canvas */}
      <div
        className={`absolute inset-0 bg-gradient-to-b ${getGradientClass()} transition-colors duration-1000`}
      />

      {/* Subtle Mesh Grid */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, rgba(255, 255, 255, 0.4) 1px, transparent 0)`,
          backgroundSize: '32px 32px',
        }}
      />

      {/* Atmospheric Particles Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full opacity-70"
      />
    </div>
  );
};
