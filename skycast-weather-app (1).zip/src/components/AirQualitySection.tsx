import React from 'react';
import {
  ShieldAlert,
  Wind,
  Heart,
  Activity,
  AlertTriangle,
  Info,
  CheckCircle2,
} from 'lucide-react';
import { AirQualityData } from '../types/weather';

interface AirQualitySectionProps {
  airQuality: AirQualityData;
  locationName: string;
}

export const AirQualitySection: React.FC<AirQualitySectionProps> = ({
  airQuality,
  locationName,
}) => {
  const pollutants = [
    {
      name: 'PM2.5',
      fullName: 'Fine Particulate Matter',
      value: airQuality.pm25,
      unit: 'µg/m³',
      limit: 25,
      description: 'Ultra-fine breathable combustion particles that penetrate deep lungs.',
    },
    {
      name: 'PM10',
      fullName: 'Coarse Particulates',
      value: airQuality.pm10,
      unit: 'µg/m³',
      limit: 50,
      description: 'Dust, pollen, and mold spores suspended in ambient air.',
    },
    {
      name: 'Ozone (O₃)',
      fullName: 'Tropospheric Ozone',
      value: airQuality.ozone,
      unit: 'µg/m³',
      limit: 100,
      description: 'Formed when pollutants react with intense solar radiation.',
    },
    {
      name: 'NO₂',
      fullName: 'Nitrogen Dioxide',
      value: airQuality.nitrogenDioxide,
      unit: 'µg/m³',
      limit: 40,
      description: 'Emissions primarily from vehicular internal combustion and power plants.',
    },
    {
      name: 'SO₂',
      fullName: 'Sulfur Dioxide',
      value: airQuality.sulphurDioxide,
      unit: 'µg/m³',
      limit: 20,
      description: 'Industrial byproducts and fossil fuel combustion by heavy infrastructure.',
    },
    {
      name: 'CO',
      fullName: 'Carbon Monoxide',
      value: airQuality.carbonMonoxide,
      unit: 'µg/m³',
      limit: 1000,
      description: 'Colorless, odorless gas generated from incomplete combustion.',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-5 h-5 text-cyan-400" />
          <h2 className="text-lg font-bold text-white tracking-tight">
            Air Quality & Atmospheric Particulate Index
          </h2>
        </div>
        <span className="text-xs text-slate-400 font-mono">
          Sensor Station: {locationName}
        </span>
      </div>

      {/* Main AQI Status Card */}
      <div
        className={`rounded-2xl border p-6 backdrop-blur-xl ${airQuality.statusBg} transition-all`}
      >
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          {/* AQI Score */}
          <div className="md:col-span-4 flex items-center gap-5">
            <div className="w-20 h-20 rounded-2xl bg-slate-950/70 border border-slate-800 flex flex-col items-center justify-center shrink-0">
              <span className="text-3xl font-extrabold font-mono text-white tabular-nums">
                {airQuality.usAqi}
              </span>
              <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider">
                US AQI
              </span>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className={`text-xl font-bold ${airQuality.statusColor}`}>
                  {airQuality.statusLabel}
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                European Index: {airQuality.europeanAqi} AQI
              </p>
            </div>
          </div>

          {/* Health Advice prose */}
          <div className="md:col-span-8 border-t md:border-t-0 md:border-l border-slate-800/80 pt-4 md:pt-0 md:pl-6">
            <p className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
              Public Health Advisory
            </p>
            <p className="text-sm text-slate-200 leading-relaxed">
              {airQuality.healthAdvice}
            </p>

            {/* Quick recommendation tokens */}
            <div className="flex flex-wrap items-center gap-4 mt-3 text-xs text-slate-300">
              <span className="flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-cyan-400" />
                <span>
                  Outdoor Sports:{' '}
                  {airQuality.usAqi <= 100 ? 'Safe to train' : 'Reduce intensity'}
                </span>
              </span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span className="flex items-center gap-1.5">
                <Heart className="w-3.5 h-3.5 text-rose-400" />
                <span>
                  Sensitive Groups:{' '}
                  {airQuality.usAqi <= 50 ? 'No precautions' : 'Limit exposure'}
                </span>
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 6 Pollutants Matrix */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {pollutants.map((p) => {
          const ratio = Math.min(100, Math.round((p.value / p.limit) * 100));
          const isHigh = ratio > 100;
          const isModerate = ratio > 65;

          return (
            <div
              key={p.name}
              className="rounded-xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 p-4 flex flex-col justify-between shadow-lg"
            >
              <div>
                <div className="flex items-center justify-between mb-1">
                  <h3 className="text-sm font-bold text-white font-mono">{p.name}</h3>
                  <span
                    className={`text-[11px] font-mono font-medium ${
                      isHigh
                        ? 'text-rose-400'
                        : isModerate
                        ? 'text-amber-400'
                        : 'text-emerald-400'
                    }`}
                  >
                    {isHigh ? 'Elevated' : isModerate ? 'Moderate' : 'Good'}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mb-3">{p.fullName}</p>
              </div>

              <div>
                <div className="flex items-baseline justify-between mb-1.5">
                  <span className="text-2xl font-bold font-mono text-white tabular-nums">
                    {p.value}
                  </span>
                  <span className="text-xs font-mono text-slate-400">
                    {p.unit} (Limit: {p.limit})
                  </span>
                </div>

                {/* Progress ratio bar */}
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      isHigh
                        ? 'bg-rose-500'
                        : isModerate
                        ? 'bg-amber-400'
                        : 'bg-emerald-400'
                    }`}
                    style={{ width: `${Math.min(100, ratio)}%` }}
                  />
                </div>

                <p className="text-[11px] text-slate-400 mt-2 line-clamp-2">
                  {p.description}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
