import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  Navigation,
  Bookmark,
  Compass,
  X,
  Loader2,
  Check,
  MapPin,
  Clock,
  Sparkles,
  Download,
} from 'lucide-react';
import { ActiveTab, LocationData, WeatherUnit } from '../types/weather';
import { searchCities, DEFAULT_CITIES } from '../services/weatherApi';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  currentLocation: LocationData;
  onSelectLocation: (loc: LocationData) => void;
  unit: WeatherUnit;
  onToggleUnit: () => void;
  onUseCurrentLocation: () => void;
  isLocating: boolean;
  savedLocations: LocationData[];
  onToggleSaveLocation: (loc: LocationData) => void;
  isCurrentSaved: boolean;
  onOpenDownloadModal?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  currentLocation,
  onSelectLocation,
  unit,
  onToggleUnit,
  onUseCurrentLocation,
  isLocating,
  savedLocations,
  onToggleSaveLocation,
  isCurrentSaved,
  onOpenDownloadModal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<LocationData[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [showFavoritesDropdown, setShowFavoritesDropdown] = useState(false);

  const searchInputRef = useRef<HTMLInputElement>(null);
  const favoritesRef = useRef<HTMLDivElement>(null);

  // Debounced search
  useEffect(() => {
    if (!searchQuery.trim() || searchQuery.trim().length < 2) {
      setSearchResults([]);
      setIsSearching(false);
      return;
    }

    setIsSearching(true);
    const timer = setTimeout(async () => {
      const results = await searchCities(searchQuery);
      setSearchResults(results);
      setIsSearching(false);
    }, 280);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Focus input when modal opens
  useEffect(() => {
    if (showSearchModal) {
      setTimeout(() => searchInputRef.current?.focus(), 50);
    }
  }, [showSearchModal]);

  // Click outside to close favorites
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (
        favoritesRef.current &&
        !favoritesRef.current.contains(e.target as Node)
      ) {
        setShowFavoritesDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const navItems: { id: ActiveTab; label: string }[] = [
    { id: 'overview', label: 'Overview' },
    { id: 'hourly', label: 'Hourly' },
    { id: '7day', label: '7-Day Forecast' },
    { id: 'airquality', label: 'Air Quality' },
    { id: 'radar', label: 'Radar Map' },
    { id: 'planner', label: 'Planner' },
  ];

  return (
    <>
      <header className="sticky top-0 z-40 w-full backdrop-blur-md bg-slate-950/75 border-b border-slate-800/80 transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          {/* Zone 1: Single text element wordmark */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('overview')}
              className="group flex items-center gap-2.5 text-left focus:outline-none"
            >
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-500 to-sky-400 p-[1px] shadow-sm">
                <div className="w-full h-full bg-slate-950 rounded-[7px] flex items-center justify-center">
                  <Compass className="w-4 h-4 text-cyan-400 group-hover:rotate-45 transition-transform duration-300" />
                </div>
              </div>
              <span className="text-xl font-bold tracking-tight text-white font-sans">
                SkyCast
              </span>
            </button>

            {/* Current City Indicator (clean unboxed text) */}
            <div className="hidden lg:flex items-center gap-2 pl-3 border-l border-slate-800 text-xs text-slate-400">
              <MapPin className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span className="font-medium text-slate-200 truncate max-w-[150px]">
                {currentLocation.name}
              </span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span className="text-slate-400 truncate max-w-[120px]">
                {currentLocation.country}
              </span>
            </div>
          </div>

          {/* Zone 2: 4-6 clean text navigation links */}
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all whitespace-nowrap ${
                    isActive
                      ? 'text-cyan-300 bg-cyan-950/40 border border-cyan-800/50 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1-2 primary actions */}
          <div className="flex items-center gap-2">
            {/* Search Trigger Button */}
            <button
              onClick={() => setShowSearchModal(true)}
              className="flex items-center gap-2 px-3 py-1.5 text-xs text-slate-400 bg-slate-900/80 hover:bg-slate-850 hover:text-slate-200 border border-slate-800 rounded-lg transition-colors cursor-pointer"
              title="Search world cities"
            >
              <Search className="w-3.5 h-3.5 text-slate-400" />
              <span className="hidden sm:inline">Search city...</span>
            </button>

            {/* My Location GPS Button */}
            <button
              onClick={onUseCurrentLocation}
              disabled={isLocating}
              className="p-2 text-slate-400 hover:text-cyan-400 hover:bg-slate-900 border border-slate-800 rounded-lg transition-colors cursor-pointer disabled:opacity-50"
              title="Detect current location"
            >
              {isLocating ? (
                <Loader2 className="w-4 h-4 animate-spin text-cyan-400" />
              ) : (
                <Navigation className="w-4 h-4" />
              )}
            </button>

            {/* Favorite Bookmark Toggle */}
            <button
              onClick={() => onToggleSaveLocation(currentLocation)}
              className={`p-2 border border-slate-800 rounded-lg transition-colors cursor-pointer ${
                isCurrentSaved
                  ? 'text-amber-400 bg-amber-950/20 border-amber-800/40 hover:bg-amber-950/40'
                  : 'text-slate-400 hover:text-amber-400 hover:bg-slate-900'
              }`}
              title={isCurrentSaved ? 'Saved in favorites' : 'Save to favorites'}
            >
              <Bookmark
                className="w-4 h-4"
                fill={isCurrentSaved ? 'currentColor' : 'none'}
              />
            </button>

            {/* Favorites Dropdown Menu */}
            <div className="relative" ref={favoritesRef}>
              <button
                onClick={() => setShowFavoritesDropdown(!showFavoritesDropdown)}
                className="px-2.5 py-1.5 text-xs text-slate-300 bg-slate-900 hover:bg-slate-850 border border-slate-800 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
                title="View saved cities"
              >
                <span>Saved</span>
                {savedLocations.length > 0 && (
                  <span className="w-4 h-4 rounded-full bg-cyan-500/20 text-cyan-400 text-[10px] font-mono flex items-center justify-center font-bold">
                    {savedLocations.length}
                  </span>
                )}
              </button>

              {showFavoritesDropdown && (
                <div className="absolute right-0 mt-2 w-64 bg-slate-900/95 backdrop-blur-xl border border-slate-800 rounded-xl shadow-2xl p-2 z-50">
                  <div className="px-2.5 py-1.5 text-xs font-semibold text-slate-400 border-b border-slate-800/80 mb-1 flex items-center justify-between">
                    <span>Saved Locations</span>
                    <span className="text-[11px] text-slate-500">{savedLocations.length} cities</span>
                  </div>

                  {savedLocations.length === 0 ? (
                    <div className="p-3 text-center text-xs text-slate-500">
                      No saved locations yet. Click the bookmark icon to save cities.
                    </div>
                  ) : (
                    <div className="max-h-60 overflow-y-auto space-y-1 thin-scrollbar">
                      {savedLocations.map((loc) => {
                        const isSelected = loc.id === currentLocation.id;
                        return (
                          <button
                            key={loc.id}
                            onClick={() => {
                              onSelectLocation(loc);
                              setShowFavoritesDropdown(false);
                            }}
                            className={`w-full text-left px-2.5 py-2 rounded-lg text-xs flex items-center justify-between transition-colors ${
                              isSelected
                                ? 'bg-cyan-950/40 text-cyan-300 font-medium'
                                : 'text-slate-300 hover:bg-slate-800/80'
                            }`}
                          >
                            <div className="truncate pr-2">
                              <p className="truncate font-medium">{loc.name}</p>
                              <p className="text-[11px] text-slate-500 truncate">
                                {loc.country}
                              </p>
                            </div>
                            {isSelected && (
                              <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                            )}
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Metric / Imperial Unit Toggle */}
            <div className="flex items-center p-0.5 bg-slate-900 border border-slate-800 rounded-lg">
              <button
                onClick={() => unit !== 'metric' && onToggleUnit()}
                className={`px-2 py-1 text-xs font-mono font-medium rounded-md transition-all ${
                  unit === 'metric'
                    ? 'bg-cyan-500/20 text-cyan-300 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                °C
              </button>
              <button
                onClick={() => unit !== 'imperial' && onToggleUnit()}
                className={`px-2 py-1 text-xs font-mono font-medium rounded-md transition-all ${
                  unit === 'imperial'
                    ? 'bg-cyan-500/20 text-cyan-300 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                °F
              </button>
            </div>

            {/* Download Code ZIP Button */}
            {onOpenDownloadModal && (
              <button
                onClick={onOpenDownloadModal}
                className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-semibold text-slate-950 bg-gradient-to-r from-cyan-400 to-sky-400 hover:from-cyan-300 hover:to-sky-300 rounded-lg transition-all shadow-md shadow-cyan-500/20 cursor-pointer"
                title="Download full project code as ZIP"
              >
                <Download className="w-3.5 h-3.5 stroke-[2.5]" />
                <span className="hidden xs:inline">Download</span>
                <span>.ZIP</span>
              </button>
            )}
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="md:hidden flex items-center gap-1 px-4 py-2 overflow-x-auto no-scrollbar border-t border-slate-850 bg-slate-950/90">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`px-3 py-1 text-xs font-medium rounded-md transition-all whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'text-cyan-300 bg-cyan-950/40 border border-cyan-800/50'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      </header>

      {/* Global City Search Modal */}
      {showSearchModal && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4 bg-slate-950/80 backdrop-blur-md">
          <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Search Input bar */}
            <div className="p-4 border-b border-slate-800 flex items-center gap-3">
              <Search className="w-5 h-5 text-slate-400 shrink-0" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search worldwide city, state, or country..."
                className="w-full bg-transparent text-white placeholder-slate-500 text-sm focus:outline-none"
              />
              {isSearching && (
                <Loader2 className="w-4 h-4 animate-spin text-cyan-400 shrink-0" />
              )}
              {searchQuery && !isSearching && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="text-slate-500 hover:text-slate-300"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
              <button
                onClick={() => setShowSearchModal(false)}
                className="px-2 py-1 text-xs text-slate-400 hover:text-slate-200 bg-slate-800/60 rounded-md"
              >
                ESC
              </button>
            </div>

            {/* Results or Suggested cities */}
            <div className="max-h-80 overflow-y-auto p-3 space-y-1 thin-scrollbar">
              {searchQuery.trim().length >= 2 ? (
                searchResults.length > 0 ? (
                  searchResults.map((loc) => (
                    <button
                      key={loc.id}
                      onClick={() => {
                        onSelectLocation(loc);
                        setShowSearchModal(false);
                        setSearchQuery('');
                      }}
                      className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-slate-800/80 flex items-center justify-between text-slate-200 transition-colors group"
                    >
                      <div className="flex items-center gap-3">
                        <MapPin className="w-4 h-4 text-cyan-400 shrink-0" />
                        <div>
                          <p className="text-sm font-medium text-white group-hover:text-cyan-300 transition-colors">
                            {loc.name}
                          </p>
                          <p className="text-xs text-slate-400">
                            {[loc.admin1, loc.country].filter(Boolean).join(', ')}
                          </p>
                        </div>
                      </div>
                      <span className="text-[11px] font-mono text-slate-500">
                        {loc.latitude.toFixed(2)}°, {loc.longitude.toFixed(2)}°
                      </span>
                    </button>
                  ))
                ) : !isSearching ? (
                  <div className="py-8 text-center text-xs text-slate-500">
                    No matching cities found. Try checking the spelling.
                  </div>
                ) : null
              ) : (
                <div>
                  <div className="px-3 py-2 text-xs font-semibold text-slate-400">
                    Popular Global Metropolises
                  </div>
                  <div className="grid grid-cols-2 gap-1.5 pt-1">
                    {DEFAULT_CITIES.map((loc) => (
                      <button
                        key={loc.id}
                        onClick={() => {
                          onSelectLocation(loc);
                          setShowSearchModal(false);
                        }}
                        className="text-left px-3 py-2 rounded-lg bg-slate-850 hover:bg-slate-800/90 text-xs text-slate-200 flex items-center justify-between transition-colors"
                      >
                        <span className="font-medium">{loc.name}</span>
                        <span className="text-[11px] text-slate-400 font-mono">
                          {loc.countryCode}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};
