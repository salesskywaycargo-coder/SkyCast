import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Layers,
  ZoomIn,
  ZoomOut,
  MapPin,
  Compass,
  CloudRain,
  Eye,
  Sliders,
  Maximize2,
} from 'lucide-react';
import { LocationData } from '../types/weather';

interface InteractiveRadarMapProps {
  location: LocationData;
}

interface RadarFrame {
  time: number;
  path: string;
}

export const InteractiveRadarMap: React.FC<InteractiveRadarMapProps> = ({
  location,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentFrameIndex, setCurrentFrameIndex] = useState(0);
  const [radarFrames, setRadarFrames] = useState<RadarFrame[]>([]);
  const [radarHost, setRadarHost] = useState('https://tilecache.rainviewer.com');
  const [zoom, setZoom] = useState(7);
  const [mapCenter, setMapCenter] = useState({
    lat: location.latitude,
    lon: location.longitude,
  });
  const [selectedLayer, setSelectedLayer] = useState<'radar' | 'clouds' | 'satellite'>(
    'radar'
  );
  const [radarOpacity, setRadarOpacity] = useState(0.8);
  const [isLoading, setIsLoading] = useState(true);

  // Update map center when location changes
  useEffect(() => {
    setMapCenter({
      lat: location.latitude,
      lon: location.longitude,
    });
  }, [location]);

  // Fetch real-time RainViewer radar frames
  useEffect(() => {
    let mounted = true;
    async function fetchRadarData() {
      try {
        setIsLoading(true);
        const res = await fetch('https://api.rainviewer.com/public/weather-maps.json');
        if (!res.ok) throw new Error('Failed to fetch radar timestamps');
        const data = await res.json();

        if (mounted && data.radar && data.radar.past && data.radar.past.length > 0) {
          const frames = [...data.radar.past];
          if (data.radar.nowcast && data.radar.nowcast.length > 0) {
            frames.push(...data.radar.nowcast.slice(0, 3));
          }
          setRadarFrames(frames);
          setRadarHost(data.host || 'https://tilecache.rainviewer.com');
          setCurrentFrameIndex(Math.max(0, data.radar.past.length - 1));
        }
      } catch (err) {
        console.warn('RainViewer API offline, using standard radar simulation', err);
      } finally {
        if (mounted) setIsLoading(false);
      }
    }

    fetchRadarData();
    return () => {
      mounted = false;
    };
  }, []);

  // Playback timer
  useEffect(() => {
    if (!isPlaying || radarFrames.length === 0) return;

    const interval = setInterval(() => {
      setCurrentFrameIndex((prev) => (prev + 1) % radarFrames.length);
    }, 700);

    return () => clearInterval(interval);
  }, [isPlaying, radarFrames]);

  // Calculate Slippy Map tile coordinates
  const lat2tile = (lat: number, zoomLevel: number) => {
    return Math.floor(
      ((1 -
        Math.log(
          Math.tan((lat * Math.PI) / 180) + 1 / Math.cos((lat * Math.PI) / 180)
        ) /
          Math.PI) /
        2) *
        Math.pow(2, zoomLevel)
    );
  };

  const lon2tile = (lon: number, zoomLevel: number) => {
    return Math.floor(((lon + 180) / 360) * Math.pow(2, zoomLevel));
  };

  const centerTileX = lon2tile(mapCenter.lon, zoom);
  const centerTileY = lat2tile(mapCenter.lat, zoom);

  // Generate 3x3 grid of tiles around center
  const tiles: { x: number; y: number; offsetX: number; offsetY: number }[] = [];
  for (let dx = -1; dx <= 1; dx++) {
    for (let dy = -1; dy <= 1; dy++) {
      tiles.push({
        x: centerTileX + dx,
        y: centerTileY + dy,
        offsetX: dx * 256,
        offsetY: dy * 256,
      });
    }
  }

  // Format frame time
  const formatFrameTime = (timestamp: number) => {
    const d = new Date(timestamp * 1000);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const currentFrame = radarFrames[currentFrameIndex];

  // Pan controls
  const handlePan = (dLat: number, dLon: number) => {
    setMapCenter((prev) => ({
      lat: Math.max(-85, Math.min(85, prev.lat + dLat)),
      lon: ((prev.lon + dLon + 180) % 360) - 180,
    }));
  };

  return (
    <div className="rounded-2xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 p-6 shadow-xl">
      {/* Title & Controls Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
        <div>
          <div className="flex items-center gap-2">
            <CloudRain className="w-5 h-5 text-cyan-400" />
            <h2 className="text-lg font-bold text-white tracking-tight">
              Live Weather Radar & Precipitation Doppler
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Focus: {location.name}, {location.country} ({mapCenter.lat.toFixed(2)}°,{' '}
            {mapCenter.lon.toFixed(2)}°)
          </p>
        </div>

        {/* Layer Selector */}
        <div className="flex items-center gap-1 p-1 bg-slate-950/80 border border-slate-800 rounded-lg">
          <button
            onClick={() => setSelectedLayer('radar')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              selectedLayer === 'radar'
                ? 'bg-slate-800 text-cyan-300'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Precipitation
          </button>
          <button
            onClick={() => setSelectedLayer('clouds')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              selectedLayer === 'clouds'
                ? 'bg-slate-800 text-cyan-300'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Cloud Cover
          </button>
          <button
            onClick={() => setSelectedLayer('satellite')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              selectedLayer === 'satellite'
                ? 'bg-slate-800 text-cyan-300'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Satellite
          </button>
        </div>
      </div>

      {/* Main Interactive Map Viewport */}
      <div className="relative w-full h-[440px] sm:h-[480px] bg-slate-950 rounded-xl overflow-hidden border border-slate-800 shadow-inner select-none">
        {/* Map Tiles Container */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="relative w-[256px] h-[256px]">
            {tiles.map((tile) => {
              const baseTileUrl = `https://tile.openstreetmap.org/${zoom}/${tile.x}/${tile.y}.png`;
              const radarTileUrl =
                currentFrame && selectedLayer === 'radar'
                  ? `${radarHost}${currentFrame.path}/256/${zoom}/${tile.x}/${tile.y}/2/1_1.png`
                  : null;

              return (
                <div
                  key={`${zoom}-${tile.x}-${tile.y}`}
                  className="absolute w-[256px] h-[256px] transition-transform duration-75"
                  style={{
                    transform: `translate(${tile.offsetX}px, ${tile.offsetY}px)`,
                  }}
                >
                  {/* Dark Mode Basemap Filter */}
                  <img
                    src={baseTileUrl}
                    alt=""
                    className="w-full h-full object-cover filter invert brightness-[0.75] contrast-[1.3] hue-rotate-[190deg]"
                    loading="lazy"
                  />

                  {/* Weather Radar Layer */}
                  {radarTileUrl && (
                    <img
                      src={radarTileUrl}
                      alt=""
                      className="absolute inset-0 w-full h-full object-cover mix-blend-screen pointer-events-none"
                      style={{ opacity: radarOpacity }}
                      onError={(e) => {
                        // Suppress tile load errors silently
                        (e.target as HTMLElement).style.display = 'none';
                      }}
                    />
                  )}
                </div>
              );
            })}

            {/* Target Location Pin */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20 pointer-events-none flex flex-col items-center">
              <div className="w-4 h-4 rounded-full bg-cyan-400 ring-4 ring-cyan-500/40 shadow-lg animate-pulse" />
              <div className="px-2 py-0.5 rounded bg-slate-900/90 border border-slate-700 text-[10px] font-mono text-white mt-1 shadow-md whitespace-nowrap">
                {location.name}
              </div>
            </div>
          </div>
        </div>

        {/* Map HUD Top Overlays: Zoom & Pan */}
        <div className="absolute top-3 right-3 z-30 flex flex-col gap-1.5">
          <button
            onClick={() => setZoom((z) => Math.min(11, z + 1))}
            className="w-8 h-8 rounded-lg bg-slate-900/90 hover:bg-slate-800 border border-slate-750 text-white flex items-center justify-center shadow-lg transition-colors cursor-pointer"
            title="Zoom In"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            onClick={() => setZoom((z) => Math.max(4, z - 1))}
            className="w-8 h-8 rounded-lg bg-slate-900/90 hover:bg-slate-800 border border-slate-750 text-white flex items-center justify-center shadow-lg transition-colors cursor-pointer"
            title="Zoom Out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button
            onClick={() =>
              setMapCenter({
                lat: location.latitude,
                lon: location.longitude,
              })
            }
            className="w-8 h-8 rounded-lg bg-slate-900/90 hover:bg-slate-800 border border-slate-750 text-cyan-400 flex items-center justify-center shadow-lg transition-colors cursor-pointer"
            title="Recenter on City"
          >
            <MapPin className="w-4 h-4" />
          </button>
        </div>

        {/* Directional Pan Arrows on Left */}
        <div className="absolute top-3 left-3 z-30 flex flex-col items-center gap-1 bg-slate-900/80 backdrop-blur-md p-1.5 rounded-xl border border-slate-800">
          <button
            onClick={() => handlePan(1.5, 0)}
            className="w-6 h-6 text-slate-300 hover:text-white flex items-center justify-center text-xs font-mono"
            title="Pan North"
          >
            ▲
          </button>
          <div className="flex gap-1">
            <button
              onClick={() => handlePan(0, -1.5)}
              className="w-6 h-6 text-slate-300 hover:text-white flex items-center justify-center text-xs font-mono"
              title="Pan West"
            >
              ◀
            </button>
            <span className="w-6 h-6 flex items-center justify-center text-[10px] font-mono text-cyan-400 font-bold">
              Z{zoom}
            </span>
            <button
              onClick={() => handlePan(0, 1.5)}
              className="w-6 h-6 text-slate-300 hover:text-white flex items-center justify-center text-xs font-mono"
              title="Pan East"
            >
              ▶
            </button>
          </div>
          <button
            onClick={() => handlePan(-1.5, 0)}
            className="w-6 h-6 text-slate-300 hover:text-white flex items-center justify-center text-xs font-mono"
            title="Pan South"
          >
            ▼
          </button>
        </div>

        {/* Doppler Color Legend on Bottom Left */}
        <div className="absolute bottom-3 left-3 z-30 bg-slate-900/90 backdrop-blur-md border border-slate-800 rounded-xl p-2.5 shadow-lg text-[11px] text-slate-300">
          <p className="font-semibold text-white mb-1.5">Precipitation Rate</p>
          <div className="flex items-center gap-1.5 font-mono text-[10px]">
            <span className="w-3 h-2.5 rounded-sm bg-cyan-400" />
            <span>Light</span>
            <span className="w-3 h-2.5 rounded-sm bg-emerald-400 ml-1" />
            <span>Moderate</span>
            <span className="w-3 h-2.5 rounded-sm bg-amber-400 ml-1" />
            <span>Heavy</span>
            <span className="w-3 h-2.5 rounded-sm bg-rose-500 ml-1" />
            <span>Hail / Severe</span>
          </div>
        </div>

        {/* Current Time Stamp Indicator */}
        {currentFrame && (
          <div className="absolute bottom-3 right-3 z-30 bg-slate-900/90 backdrop-blur-md border border-slate-800 rounded-xl px-3 py-1.5 shadow-lg text-xs font-mono text-cyan-300 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
            <span>Frame: {formatFrameTime(currentFrame.time)}</span>
          </div>
        )}
      </div>

      {/* Radar Timeline & Playback Bar */}
      {radarFrames.length > 0 && (
        <div className="mt-4 p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 w-full sm:w-auto">
            {/* Play / Pause */}
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="p-2.5 rounded-xl bg-cyan-500 text-slate-950 hover:bg-cyan-400 transition-colors font-semibold shadow-md flex items-center justify-center cursor-pointer shrink-0"
              title={isPlaying ? 'Pause radar animation' : 'Play radar animation'}
            >
              {isPlaying ? (
                <Pause className="w-4 h-4 fill-current" />
              ) : (
                <Play className="w-4 h-4 fill-current ml-0.5" />
              )}
            </button>

            {/* Reset to Latest */}
            <button
              onClick={() => {
                setIsPlaying(false);
                setCurrentFrameIndex(radarFrames.length - 1);
              }}
              className="p-2.5 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white transition-colors cursor-pointer shrink-0"
              title="Jump to current live frame"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            {/* Frame Scrubber Slider */}
            <div className="flex-1 sm:w-64 flex flex-col gap-1">
              <input
                type="range"
                min="0"
                max={radarFrames.length - 1}
                value={currentFrameIndex}
                onChange={(e) => {
                  setIsPlaying(false);
                  setCurrentFrameIndex(Number(e.target.value));
                }}
                className="w-full accent-cyan-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] font-mono text-slate-500">
                <span>-2 Hours</span>
                <span className="text-cyan-400 font-semibold">Live</span>
                <span>+30m Forecast</span>
              </div>
            </div>
          </div>

          {/* Opacity Control */}
          <div className="flex items-center gap-3 w-full sm:w-auto justify-end text-xs text-slate-400">
            <span>Radar Density:</span>
            <input
              type="range"
              min="0.2"
              max="1.0"
              step="0.1"
              value={radarOpacity}
              onChange={(e) => setRadarOpacity(Number(e.target.value))}
              className="w-24 accent-cyan-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
            />
            <span className="font-mono text-white text-[11px] w-8">
              {Math.round(radarOpacity * 100)}%
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
