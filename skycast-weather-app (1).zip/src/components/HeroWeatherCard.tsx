import React from 'react';
import {
  Wind,
  Droplets,
  Eye,
  Gauge,
  ArrowUp,
  ArrowDown,
  RefreshCw,
  Sun,
  ShieldAlert,
} from 'lucide-react';
import { WeatherData, WeatherUnit } from '../types/weather';
import {
  formatPrecipitation,
  formatPressure,
  formatSpeed,
  formatTemp,
  formatVisibility,
  getWindDirectionCardinal,
} from '../services/weatherUtils';
import { WeatherIcon } from './WeatherIcon';

interface HeroWeatherCardProps {
  weather: WeatherData;
  unit: WeatherUnit;
  onRefresh: () => void;
  isRefreshing: boolean;
}

export const HeroWeatherCard: React.FC<HeroWeatherCardProps> = ({
  weather,
  unit,
  onRefresh,
  isRefreshing,
}) => {
  const { current, location, daily, airQuality, lastUpdated } = weather;
  const todayForecast = daily[0] || null;

  // Generate an authentic atmospheric condition takeaway
  const generateAtmosphericSummary = () => {
    if (current.weatherTheme === 'rain' || current.weatherTheme === 'thunder') {
      return `Active precipitation detected (${formatPrecipitation(
        current.precipitation,
        unit
      )}). Umbrella strongly advised throughout the day.`;
    }
    if (current.weatherTheme === 'snow') {
      return `Snow flurries observed. Road surfaces may be slick; allow extra travel time.`;
    }
    if (current.weatherTheme === 'fog') {
      return `Reduced visibility (${formatVisibility(
        current.visibility,
        unit
      )}) due to dense ground moisture. Caution advised when commuting.`;
    }
    if (current.uvIndex >= 7) {
      return `High solar radiation index (${current.uvIndex}). Sunscreen SPF 30+ and UV-blocking eyewear recommended.`;
    }
    if (current.windSpeed > 35) {
      return `Brisk winds gusting up to ${formatSpeed(
        current.windGusts,
        unit
      )}. Secure lightweight outdoor fixtures.`;
    }
    if (current.isDay) {
      return `Comfortable atmospheric conditions. Ideal window for outdoor recreation and activities.`;
    }
    return `Calm nocturnal sky. Cooling down toward an overnight low of ${
      todayForecast ? formatTemp(todayForecast.tempMin, unit) : 'mild'
    }.`;
  };

  return (
    <div className="relative overflow-hidden rounded-2xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 p-6 sm:p-8 transition-all shadow-xl">
      {/* Subtle Corner Glow Accent */}
      <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none" />

      {/* Top row: Location & Live Status */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
            <span>{location.country}</span>
            {location.admin1 && (
              <>
                <span aria-hidden="true">·</span>
                <span>{location.admin1}</span>
              </>
            )}
            <span aria-hidden="true">·</span>
            <span>Local Time {weather.current.time.slice(11, 16)}</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
            {location.name}
          </h1>
        </div>

        {/* Refresh & Last Updated */}
        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <p className="text-[11px] text-slate-400">Updated</p>
            <p className="text-xs font-mono text-slate-300 tabular-nums">
              {lastUpdated}
            </p>
          </div>
          <button
            onClick={onRefresh}
            disabled={isRefreshing}
            className="p-2.5 bg-slate-850 hover:bg-slate-800 border border-slate-800 rounded-xl text-slate-300 hover:text-cyan-400 transition-colors cursor-pointer disabled:opacity-50"
            title="Refresh weather data"
          >
            <RefreshCw
              className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-cyan-400' : ''}`}
            />
          </button>
        </div>
      </div>

      {/* Main Meteorological Core */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* Left Side: Temperature & Icon */}
        <div className="lg:col-span-7 flex flex-col sm:flex-row items-start sm:items-center gap-6">
          <div className="flex items-center gap-5">
            <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-750 flex items-center justify-center shrink-0 shadow-inner">
              <WeatherIcon
                theme={current.weatherTheme}
                isDay={current.isDay}
                size={56}
              />
            </div>

            <div>
              <div className="flex items-baseline gap-2">
                <span className="text-6xl sm:text-7xl font-extrabold tracking-tighter text-white font-mono tabular-nums">
                  {formatTemp(current.temperature, unit)}
                </span>
                <span className="text-xl sm:text-2xl font-medium text-slate-400">
                  {current.weatherDescription}
                </span>
              </div>

              {/* Thermal Range & Feels Like */}
              <div className="flex items-center gap-3 mt-2 text-xs sm:text-sm text-slate-300">
                <span>
                  Feels like{' '}
                  <strong className="text-white font-mono tabular-nums">
                    {formatTemp(current.apparentTemperature, unit)}
                  </strong>
                </span>

                {todayForecast && (
                  <>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className="flex items-center gap-0.5 text-slate-300 font-mono tabular-nums">
                      <ArrowUp className="w-3.5 h-3.5 text-rose-400" />
                      {formatTemp(todayForecast.tempMax, unit)}
                    </span>
                    <span className="flex items-center gap-0.5 text-slate-300 font-mono tabular-nums">
                      <ArrowDown className="w-3.5 h-3.5 text-cyan-400" />
                      {formatTemp(todayForecast.tempMin, unit)}
                    </span>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Key Telemetry Pods */}
        <div className="lg:col-span-5 grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-2 gap-3">
          {/* Wind */}
          <div className="p-3.5 rounded-xl bg-slate-850/60 border border-slate-800/80">
            <div className="flex items-center gap-1.5 text-slate-400 text-xs mb-1">
              <Wind className="w-3.5 h-3.5 text-cyan-400" />
              <span>Wind</span>
            </div>
            <p className="text-base font-semibold text-white font-mono tabular-nums">
              {formatSpeed(current.windSpeed, unit)}
            </p>
            <p className="text-[11px] text-slate-400 font-mono mt-0.5">
              {getWindDirectionCardinal(current.windDirection)} ({current.windDirection}°)
            </p>
          </div>

          {/* Humidity */}
          <div className="p-3.5 rounded-xl bg-slate-850/60 border border-slate-800/80">
            <div className="flex items-center gap-1.5 text-slate-400 text-xs mb-1">
              <Droplets className="w-3.5 h-3.5 text-sky-400" />
              <span>Humidity</span>
            </div>
            <p className="text-base font-semibold text-white font-mono tabular-nums">
              {current.relativeHumidity}%
            </p>
            <p className="text-[11px] text-slate-400 font-mono mt-0.5">
              Dew pt: {formatTemp(current.dewPoint, unit)}
            </p>
          </div>

          {/* UV Index */}
          <div className="p-3.5 rounded-xl bg-slate-850/60 border border-slate-800/80">
            <div className="flex items-center gap-1.5 text-slate-400 text-xs mb-1">
              <Sun className="w-3.5 h-3.5 text-amber-400" />
              <span>UV Index</span>
            </div>
            <p className="text-base font-semibold text-white font-mono tabular-nums">
              {current.uvIndex} <span className="text-xs font-sans text-slate-400">/ 11+</span>
            </p>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {current.uvIndex <= 2
                ? 'Minimal'
                : current.uvIndex <= 5
                ? 'Moderate'
                : 'Intense'}
            </p>
          </div>

          {/* Air Quality Quick Capsule */}
          <div className="p-3.5 rounded-xl bg-slate-850/60 border border-slate-800/80">
            <div className="flex items-center gap-1.5 text-slate-400 text-xs mb-1">
              <ShieldAlert className="w-3.5 h-3.5 text-emerald-400" />
              <span>Air Quality</span>
            </div>
            <div className="flex items-baseline gap-1.5">
              <p className="text-base font-semibold text-white font-mono tabular-nums">
                {airQuality.usAqi}
              </p>
              <span className={`text-xs font-medium ${airQuality.statusColor}`}>
                {airQuality.statusLabel}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono mt-0.5">
              PM2.5: {airQuality.pm25} µg/m³
            </p>
          </div>
        </div>
      </div>

      {/* Atmospheric Briefing Banner */}
      <div className="mt-6 pt-5 border-t border-slate-800/80 flex items-start gap-3 text-xs sm:text-sm text-slate-300">
        <div className="w-2 h-2 rounded-full bg-cyan-400 mt-1.5 shrink-0 shadow-[0_0_8px_rgba(6,182,212,0.8)]" />
        <p className="leading-relaxed text-slate-300">
          <strong className="text-white font-semibold mr-1">Atmospheric Summary:</strong>
          {generateAtmosphericSummary()}
        </p>
      </div>
    </div>
  );
};
