import React from 'react';
import {
  Sun,
  Moon,
  Cloud,
  CloudSun,
  CloudMoon,
  CloudRain,
  CloudRainWind,
  CloudDrizzle,
  CloudSnow,
  CloudLightning,
  CloudFog,
  Snowflake,
  SunMedium,
  MoonStar,
  Wind,
  Droplets,
} from 'lucide-react';
import { WeatherTheme } from '../types/weather';

interface WeatherIconProps {
  theme: WeatherTheme;
  isDay?: boolean;
  size?: number;
  className?: string;
}

export const WeatherIcon: React.FC<WeatherIconProps> = ({
  theme,
  isDay = true,
  size = 28,
  className = '',
}) => {
  const iconProps = {
    size,
    className,
  };

  switch (theme) {
    case 'clear-day':
      return <Sun {...iconProps} className={`text-amber-400 stroke-[1.75] ${className}`} />;
    case 'clear-night':
      return <MoonStar {...iconProps} className={`text-indigo-300 stroke-[1.75] ${className}`} />;
    case 'cloudy':
      return isDay ? (
        <CloudSun {...iconProps} className={`text-sky-300 stroke-[1.75] ${className}`} />
      ) : (
        <CloudMoon {...iconProps} className={`text-indigo-300 stroke-[1.75] ${className}`} />
      );
    case 'rain':
      return <CloudRain {...iconProps} className={`text-cyan-400 stroke-[1.75] ${className}`} />;
    case 'snow':
      return <CloudSnow {...iconProps} className={`text-sky-200 stroke-[1.75] ${className}`} />;
    case 'thunder':
      return <CloudLightning {...iconProps} className={`text-amber-300 stroke-[1.75] ${className}`} />;
    case 'fog':
      return <CloudFog {...iconProps} className={`text-slate-300 stroke-[1.75] ${className}`} />;
    default:
      return <Cloud {...iconProps} className={`text-slate-300 stroke-[1.75] ${className}`} />;
  }
};
