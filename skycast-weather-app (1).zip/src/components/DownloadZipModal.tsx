import React, { useState } from 'react';
import {
  Download,
  FolderArchive,
  FileCode2,
  CheckCircle,
  Copy,
  Terminal,
  ExternalLink,
  Layers,
  Sparkles,
  ShieldCheck,
} from 'lucide-react';
import JSZip from 'jszip';

interface DownloadZipModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadZipModal: React.FC<DownloadZipModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState(false);

  if (!isOpen) return null;

  const handleDownload = async () => {
    setIsGenerating(true);
    try {
      // 1. Fetch pre-built zip
      const res = await fetch('/skycast-weather-app.zip');
      if (res.ok) {
        const blob = await res.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'skycast-weather-app.zip';
        document.body.appendChild(a);
        a.click();
        setTimeout(() => {
          window.URL.revokeObjectURL(url);
          document.body.removeChild(a);
        }, 100);
        setIsGenerating(false);
        return;
      }
      throw new Error('Static zip file fetch status not OK');
    } catch (err) {
      console.warn('Fallback to base64 decoder download:', err);
      try {
        const b64Res = await fetch('/zip_base64.txt');
        if (b64Res.ok) {
          const b64 = await b64Res.text();
          const byteCharacters = atob(b64.trim());
          const byteNumbers = new Array(byteCharacters.length);
          for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
          }
          const byteArray = new Uint8Array(byteNumbers);
          const blob = new Blob([byteArray], { type: 'application/zip' });
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = 'skycast-weather-app.zip';
          document.body.appendChild(a);
          a.click();
          setTimeout(() => {
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
          }, 100);
          return;
        }
      } catch (e2) {
        console.error('Base64 decode failed:', e2);
      }

      // Final fallback: standard browser navigation download
      const a = document.createElement('a');
      a.href = '/skycast-weather-app.zip';
      a.download = 'skycast-weather-app.zip';
      document.body.appendChild(a);
      a.click();
      setTimeout(() => document.body.removeChild(a), 100);
    } finally {
      setIsGenerating(false);
    }
  };

  const copyInstallCommand = () => {
    navigator.clipboard.writeText('npm install && npm run dev');
    setCopiedCmd(true);
    setTimeout(() => setCopiedCmd(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-150">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden p-6">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <FolderArchive className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">
                Download SkyCast Source Code (.zip)
              </h3>
              <p className="text-xs text-slate-400">
                Complete, production-ready React + TypeScript + Tailwind project
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 text-xs px-2.5 py-1.5 rounded-lg bg-slate-800/80 cursor-pointer"
          >
            Close
          </button>
        </div>

        {/* Contents Checklist */}
        <div className="my-5 space-y-3">
          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs text-slate-300">
            <p className="font-semibold text-white mb-2 flex items-center gap-1.5">
              <FileCode2 className="w-4 h-4 text-cyan-400" />
              Included in the zip archive:
            </p>
            <div className="grid grid-cols-2 gap-2 font-mono text-[11px] text-slate-400">
              <span className="flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                src/App.tsx
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                src/components/*
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                src/services/weatherApi.ts
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                src/types/weather.ts
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                package.json & tsconfig
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                index.html & vite.config
              </span>
            </div>
          </div>

          {/* Quick Setup Instructions */}
          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs">
            <div className="flex items-center justify-between text-slate-300 mb-1.5 font-semibold">
              <span className="flex items-center gap-1.5">
                <Terminal className="w-4 h-4 text-cyan-400" />
                Run Locally:
              </span>
              <button
                onClick={copyInstallCommand}
                className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer font-mono"
              >
                {copiedCmd ? (
                  <>
                    <CheckCircle className="w-3 h-3 text-emerald-400" /> Copied!
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" /> Copy command
                  </>
                )}
              </button>
            </div>
            <pre className="p-2 rounded bg-slate-900 border border-slate-800/80 font-mono text-[11px] text-slate-200 overflow-x-auto">
              unzip skycast-weather-app.zip &amp;&amp; npm install &amp;&amp; npm run dev
            </pre>
          </div>
        </div>

        {/* Primary Action Button */}
        <div className="pt-2 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white rounded-xl bg-slate-800/70 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={handleDownload}
            disabled={isGenerating}
            className="px-5 py-2 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-xl transition-all shadow-md shadow-cyan-500/20 flex items-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            <span>{isGenerating ? 'Preparing Download...' : 'Download skycast-weather-app.zip'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
