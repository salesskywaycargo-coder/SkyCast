import React, { useState } from 'react';
import {
  Calendar,
  Droplets,
  Wind,
  Sun,
  Sunrise,
  Sunset,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { DailyForecastItem, WeatherUnit } from '../types/weather';
import {
  formatPrecipitation,
  formatSpeed,
  formatTemp,
  formatTempRaw,
  getWindDirectionCardinal,
} from '../services/weatherUtils';
import { WeatherIcon } from './WeatherIcon';

interface DailyForecastViewProps {
  daily: DailyForecastItem[];
  unit: WeatherUnit;
  currentTemp?: number;
}

export const DailyForecastView: React.FC<DailyForecastViewProps> = ({
  daily,
  unit,
  currentTemp,
}) => {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

  if (!daily || daily.length === 0) return null;

  // Compute week-wide minimum and maximum for proportional range bars
  const allMins = daily.map((d) => formatTempRaw(d.tempMin, unit));
  const allMaxs = daily.map((d) => formatTempRaw(d.tempMax, unit));
  const weekMin = Math.min(...allMins);
  const weekMax = Math.max(...allMaxs);
  const weekSpan = Math.max(weekMax - weekMin, 1);

  const toggleExpand = (index: number) => {
    setExpandedIndex(expandedIndex === index ? null : index);
  };

  return (
    <div className="rounded-2xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 p-6 shadow-xl">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Calendar className="w-5 h-5 text-cyan-400" />
          <h2 className="text-lg font-bold text-white tracking-tight">
            7-Day Atmospheric Outlook
          </h2>
        </div>
        <p className="text-xs text-slate-400 font-mono">
          Weekly Extremes: {weekMin}° to {weekMax}°
        </p>
      </div>

      <div className="space-y-2.5">
        {daily.map((item, index) => {
          const minRaw = formatTempRaw(item.tempMin, unit);
          const maxRaw = formatTempRaw(item.tempMax, unit);
          const leftPercent = Math.max(
            0,
            Math.min(100, ((minRaw - weekMin) / weekSpan) * 100)
          );
          const barWidth = Math.max(
            8,
            Math.min(100 - leftPercent, ((maxRaw - minRaw) / weekSpan) * 100)
          );

          // Current temp indicator dot on "Today"
          const showCurrentDot = index === 0 && currentTemp !== undefined;
          const currentRaw = currentTemp !== undefined ? formatTempRaw(currentTemp, unit) : null;
          const currentDotPercent =
            currentRaw !== null
              ? Math.max(0, Math.min(100, ((currentRaw - weekMin) / weekSpan) * 100))
              : null;

          const isExpanded = expandedIndex === index;

          return (
            <div
              key={item.date}
              className={`rounded-xl border transition-all ${
                isExpanded
                  ? 'bg-slate-850/80 border-cyan-500/30'
                  : 'bg-slate-850/30 border-slate-800/60 hover:bg-slate-850/50'
              }`}
            >
              {/* Primary Row */}
              <div
                onClick={() => toggleExpand(index)}
                className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 cursor-pointer select-none"
              >
                {/* Day name & date */}
                <div className="flex items-center gap-3 sm:w-44 shrink-0">
                  <div className="w-9 h-9 rounded-lg bg-slate-800/80 flex items-center justify-center shrink-0">
                    <WeatherIcon theme={item.weatherTheme} size={20} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-white">
                      {item.dayName}
                    </p>
                    <p className="text-[11px] text-slate-400">
                      {item.date.slice(5)} · {item.weatherDescription}
                    </p>
                  </div>
                </div>

                {/* Rain probability */}
                <div className="flex items-center gap-1.5 sm:w-24 text-xs font-mono text-slate-400">
                  <Droplets className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                  <span className={item.precipitationProbabilityMax > 20 ? 'text-sky-300 font-semibold' : ''}>
                    {item.precipitationProbabilityMax}%
                  </span>
                </div>

                {/* Thermal Range Bar */}
                <div className="flex-1 flex items-center gap-3 w-full sm:w-auto">
                  <span className="text-xs font-mono tabular-nums text-cyan-300 font-semibold w-8 text-right shrink-0">
                    {minRaw}°
                  </span>

                  {/* Relative bar track */}
                  <div className="relative flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="absolute top-0 bottom-0 rounded-full bg-gradient-to-r from-cyan-500 via-sky-400 to-amber-400"
                      style={{
                        left: `${leftPercent}%`,
                        width: `${barWidth}%`,
                      }}
                    />

                    {/* Current Temp Dot */}
                    {showCurrentDot && currentDotPercent !== null && (
                      <div
                        className="absolute top-1/2 -translate-y-1/2 w-2.5 h-2.5 rounded-full bg-white ring-2 ring-slate-900 shadow-sm"
                        style={{ left: `calc(${currentDotPercent}% - 5px)` }}
                        title={`Current: ${currentRaw}°`}
                      />
                    )}
                  </div>

                  <span className="text-xs font-mono tabular-nums text-amber-300 font-semibold w-8 shrink-0">
                    {maxRaw}°
                  </span>
                </div>

                {/* Toggle Arrow */}
                <div className="hidden sm:block text-slate-500">
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-cyan-400" />
                  ) : (
                    <ChevronDown className="w-4 h-4" />
                  )}
                </div>
              </div>

              {/* Collapsible Micro-Metrics Drawer */}
              {isExpanded && (
                <div className="px-4 pb-4 pt-1 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800">
                    <div className="flex items-center gap-1.5 text-slate-400 mb-1">
                      <Sunrise className="w-3.5 h-3.5 text-amber-400" />
                      <span>Sunrise</span>
                    </div>
                    <p className="font-mono font-medium text-slate-200">
                      {item.sunrise ? item.sunrise.slice(11, 16) : '06:15'}
                    </p>
                  </div>

                  <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800">
                    <div className="flex items-center gap-1.5 text-slate-400 mb-1">
                      <Sunset className="w-3.5 h-3.5 text-rose-400" />
                      <span>Sunset</span>
                    </div>
                    <p className="font-mono font-medium text-slate-200">
                      {item.sunset ? item.sunset.slice(11, 16) : '18:40'}
                    </p>
                  </div>

                  <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800">
                    <div className="flex items-center gap-1.5 text-slate-400 mb-1">
                      <Sun className="w-3.5 h-3.5 text-yellow-400" />
                      <span>Max UV</span>
                    </div>
                    <p className="font-mono font-medium text-slate-200">
                      {item.uvIndexMax} of 11+
                    </p>
                  </div>

                  <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800">
                    <div className="flex items-center gap-1.5 text-slate-400 mb-1">
                      <Wind className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Max Gust</span>
                    </div>
                    <p className="font-mono font-medium text-slate-200">
                      {formatSpeed(item.windSpeedMax, unit)} (
                      {getWindDirectionCardinal(item.windDirectionDominant)})
                    </p>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
