import React, { useState } from 'react';
import {
  Clock,
  Droplets,
  Wind,
  Sun,
  Navigation,
  Sparkles,
} from 'lucide-react';
import { HourlyForecastItem, WeatherUnit } from '../types/weather';
import {
  formatPrecipitation,
  formatSpeed,
  formatTemp,
  formatTempRaw,
  getWindDirectionCardinal,
} from '../services/weatherUtils';
import { WeatherIcon } from './WeatherIcon';

interface HourlyForecastViewProps {
  hourly: HourlyForecastItem[];
  unit: WeatherUnit;
}

type HourlyMode = 'temp' | 'precip' | 'wind';

export const HourlyForecastView: React.FC<HourlyForecastViewProps> = ({
  hourly,
  unit,
}) => {
  const [selectedMode, setSelectedMode] = useState<HourlyMode>('temp');
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  // Take the first 24 items for concise graph & cards
  const displayItems = hourly.slice(0, 24);
  if (displayItems.length === 0) return null;

  // Compute graph bounds
  const temps = displayItems.map((h) => formatTempRaw(h.temperature, unit));
  const minTemp = Math.min(...temps) - 2;
  const maxTemp = Math.max(...temps) + 2;
  const tempRange = Math.max(maxTemp - minTemp, 1);

  // Dimensions for SVG chart
  const svgWidth = 800;
  const svgHeight = 160;
  const paddingX = 30;
  const paddingY = 25;

  const points = displayItems.map((item, index) => {
    const rawVal = formatTempRaw(item.temperature, unit);
    const x = paddingX + (index / (displayItems.length - 1)) * (svgWidth - paddingX * 2);
    const y =
      svgHeight -
      paddingY -
      ((rawVal - minTemp) / tempRange) * (svgHeight - paddingY * 2);
    return { x, y, item, rawVal };
  });

  // Build SVG path
  const pathD = points.reduce((acc, point, i, arr) => {
    if (i === 0) return `M ${point.x} ${point.y}`;
    const prev = arr[i - 1];
    const midX = (prev.x + point.x) / 2;
    return `${acc} C ${midX} ${prev.y}, ${midX} ${point.y}, ${point.x} ${point.y}`;
  }, '');

  const areaD = `${pathD} L ${points[points.length - 1].x} ${svgHeight} L ${points[0].x} ${svgHeight} Z`;

  const hoveredPoint = hoveredIndex !== null ? points[hoveredIndex] : null;

  return (
    <div className="rounded-2xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 p-6 shadow-xl">
      {/* Header and Mode Selector */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-2">
          <Clock className="w-5 h-5 text-cyan-400" />
          <h2 className="text-lg font-bold text-white tracking-tight">
            Hourly Atmosphere (Next 24 Hours)
          </h2>
        </div>

        {/* View Mode Segmented Control */}
        <div className="flex items-center gap-1 p-1 bg-slate-950/80 border border-slate-800 rounded-lg">
          <button
            onClick={() => setSelectedMode('temp')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              selectedMode === 'temp'
                ? 'bg-slate-800 text-cyan-300 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Temperature
          </button>
          <button
            onClick={() => setSelectedMode('precip')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              selectedMode === 'precip'
                ? 'bg-slate-800 text-cyan-300 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Precipitation
          </button>
          <button
            onClick={() => setSelectedMode('wind')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              selectedMode === 'wind'
                ? 'bg-slate-800 text-cyan-300 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Wind Speed
          </button>
        </div>
      </div>

      {/* SVG Interactive Spline Chart */}
      <div className="relative w-full overflow-hidden mb-6 bg-slate-950/40 rounded-xl border border-slate-850 p-2">
        <svg
          viewBox={`0 0 ${svgWidth} ${svgHeight}`}
          className="w-full h-36 overflow-visible cursor-crosshair"
          onMouseLeave={() => setHoveredIndex(null)}
        >
          <defs>
            <linearGradient id="tempGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.35" />
              <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.0" />
            </linearGradient>
          </defs>

          {/* Grid lines */}
          <line
            x1={paddingX}
            y1={paddingY}
            x2={svgWidth - paddingX}
            y2={paddingY}
            stroke="rgba(148, 163, 184, 0.1)"
            strokeDasharray="4 4"
          />
          <line
            x1={paddingX}
            y1={svgHeight - paddingY}
            x2={svgWidth - paddingX}
            y2={svgHeight - paddingY}
            stroke="rgba(148, 163, 184, 0.1)"
            strokeDasharray="4 4"
          />

          {/* Area fill */}
          <path d={areaD} fill="url(#tempGradient)" />

          {/* Spline stroke */}
          <path
            d={pathD}
            fill="none"
            stroke="#22d3ee"
            strokeWidth="2.5"
            strokeLinecap="round"
          />

          {/* Interactive invisible hover columns */}
          {points.map((p, i) => (
            <rect
              key={i}
              x={p.x - svgWidth / (displayItems.length * 2)}
              y={0}
              width={svgWidth / displayItems.length}
              height={svgHeight}
              fill="transparent"
              className="cursor-pointer"
              onMouseEnter={() => setHoveredIndex(i)}
            />
          ))}

          {/* Dots on points */}
          {points.map((p, i) => {
            const isHovered = hoveredIndex === i;
            return (
              <g key={i}>
                <circle
                  cx={p.x}
                  cy={p.y}
                  r={isHovered ? 5 : 2.5}
                  fill={isHovered ? '#67e8f9' : '#0891b2'}
                  stroke="#0f172a"
                  strokeWidth="1.5"
                  className="transition-all duration-150"
                />
                {/* Temp label on top for every 3rd point or hovered */}
                {(i % 4 === 0 || isHovered) && (
                  <text
                    x={p.x}
                    y={p.y - 8}
                    fill={isHovered ? '#ffffff' : '#94a3b8'}
                    fontSize={isHovered ? '12' : '10'}
                    fontFamily="monospace"
                    textAnchor="middle"
                    className="select-none font-semibold"
                  >
                    {p.rawVal}°
                  </text>
                )}
              </g>
            );
          })}

          {/* Hover crosshair line */}
          {hoveredPoint && (
            <line
              x1={hoveredPoint.x}
              y1={paddingY}
              x2={hoveredPoint.x}
              y2={svgHeight}
              stroke="#22d3ee"
              strokeWidth="1"
              strokeDasharray="3 3"
            />
          )}
        </svg>

        {/* Hover info HUD floating banner */}
        {hoveredPoint && (
          <div className="absolute top-2 left-4 px-3 py-1.5 rounded-lg bg-slate-900/90 border border-slate-750 text-xs font-mono flex items-center gap-3 text-slate-200 shadow-md">
            <span className="text-cyan-400 font-bold">{hoveredPoint.item.hour}</span>
            <span>{hoveredPoint.item.weatherDescription}</span>
            <span className="text-white font-bold">{hoveredPoint.rawVal}°</span>
            <span className="text-sky-400">{hoveredPoint.item.precipitationProbability}% Rain</span>
            <span className="text-slate-400">
              {formatSpeed(hoveredPoint.item.windSpeed, unit)}
            </span>
          </div>
        )}
      </div>

      {/* Horizontally Scrollable Timeline Cards */}
      <div className="overflow-x-auto thin-scrollbar pb-3">
        <div className="flex items-stretch gap-2.5 min-w-max">
          {displayItems.map((item, index) => {
            const isHovered = hoveredIndex === index;
            const isNow = index === 0;

            return (
              <div
                key={item.time}
                onMouseEnter={() => setHoveredIndex(index)}
                className={`p-3 rounded-xl border flex flex-col items-center justify-between text-center transition-all w-24 shrink-0 cursor-pointer ${
                  isHovered
                    ? 'bg-slate-800/90 border-cyan-500/50 shadow-md'
                    : isNow
                    ? 'bg-cyan-950/20 border-cyan-800/40'
                    : 'bg-slate-850/40 border-slate-800/80 hover:bg-slate-800/50'
                }`}
              >
                {/* Hour */}
                <p className="text-xs font-semibold text-slate-300 font-mono">
                  {item.hour}
                </p>

                {/* Weather Icon */}
                <div className="my-2.5">
                  <WeatherIcon
                    theme={item.weatherTheme}
                    isDay={item.isDay}
                    size={26}
                  />
                </div>

                {/* Primary Metric based on mode */}
                {selectedMode === 'temp' && (
                  <div>
                    <p className="text-base font-bold text-white font-mono tabular-nums">
                      {formatTemp(item.temperature, unit)}
                    </p>
                    <div className="mt-1 flex items-center justify-center gap-1 text-[11px] text-sky-400 font-mono">
                      <Droplets className="w-3 h-3" />
                      <span>{item.precipitationProbability}%</span>
                    </div>
                  </div>
                )}

                {selectedMode === 'precip' && (
                  <div>
                    <p className="text-sm font-bold text-cyan-300 font-mono tabular-nums">
                      {item.precipitationProbability}%
                    </p>
                    <div className="w-12 h-1.5 bg-slate-800 rounded-full mt-1.5 overflow-hidden">
                      <div
                        className="h-full bg-cyan-400 rounded-full"
                        style={{ width: `${item.precipitationProbability}%` }}
                      />
                    </div>
                    <p className="text-[10px] text-slate-400 font-mono mt-1">
                      {formatPrecipitation(item.precipitation, unit)}
                    </p>
                  </div>
                )}

                {selectedMode === 'wind' && (
                  <div>
                    <p className="text-xs font-bold text-white font-mono tabular-nums">
                      {formatSpeed(item.windSpeed, unit)}
                    </p>
                    <div className="flex items-center justify-center gap-1 text-[11px] text-slate-400 font-mono mt-1">
                      <Navigation
                        className="w-3 h-3 text-cyan-400 transition-transform"
                        style={{
                          transform: `rotate(${item.windDirection}deg)`,
                        }}
                      />
                      <span>{getWindDirectionCardinal(item.windDirection)}</span>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
