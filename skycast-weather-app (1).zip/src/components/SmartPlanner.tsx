import React from 'react';
import {
  Sparkles,
  Footprints,
  Bike,
  UtensilsCrossed,
  Sparkle,
  Car,
  Umbrella,
  Glasses,
  Shirt,
  CheckCircle,
  AlertCircle,
  Clock,
  Compass,
} from 'lucide-react';
import { WeatherData, WeatherUnit } from '../types/weather';
import { formatSpeed, formatTemp } from '../services/weatherUtils';

interface SmartPlannerProps {
  weather: WeatherData;
  unit: WeatherUnit;
}

interface ActivityScore {
  name: string;
  icon: React.ElementType;
  score: number;
  status: 'Optimal' | 'Favorable' | 'Marginal' | 'Not Recommended';
  reason: string;
  color: string;
}

export const SmartPlanner: React.FC<SmartPlannerProps> = ({ weather, unit }) => {
  const { current, hourly, airQuality, location } = weather;

  // Compute domain activity ratings
  const computeActivities = (): ActivityScore[] => {
    // 1. Running
    let runScore = 90;
    if (current.precipitation > 0) runScore -= 35;
    if (current.temperature < 5 || current.temperature > 28) runScore -= 25;
    if (current.relativeHumidity > 75) runScore -= 15;
    if (airQuality.usAqi > 100) runScore -= 30;
    if (current.windSpeed > 30) runScore -= 15;
    runScore = Math.max(10, Math.min(98, runScore));

    // 2. Cycling
    let bikeScore = 92;
    if (current.precipitation > 0) bikeScore -= 45;
    if (current.windSpeed > 25) bikeScore -= 30;
    if (current.temperature < 8 || current.temperature > 32) bikeScore -= 20;
    if (airQuality.usAqi > 100) bikeScore -= 25;
    bikeScore = Math.max(10, Math.min(98, bikeScore));

    // 3. Outdoor Dining
    let dineScore = 95;
    if (current.precipitation > 0) dineScore -= 60;
    if (current.windSpeed > 20) dineScore -= 25;
    if (current.temperature < 17 || current.temperature > 30) dineScore -= 35;
    dineScore = Math.max(10, Math.min(98, dineScore));

    // 4. Stargazing
    let starScore = 95;
    if (current.isDay) starScore = 15;
    else {
      starScore -= current.cloudCover * 0.8;
      if (current.precipitation > 0) starScore -= 50;
      if (current.visibility < 8000) starScore -= 20;
    }
    starScore = Math.max(10, Math.min(98, Math.round(starScore)));

    // 5. Commute & Road Safety
    let roadScore = 98;
    if (current.precipitation > 2) roadScore -= 25;
    if (current.visibility < 3000) roadScore -= 35;
    if (current.windGusts > 45) roadScore -= 25;
    if (current.weatherTheme === 'snow') roadScore -= 40;
    roadScore = Math.max(15, Math.min(99, Math.round(roadScore)));

    const getStatus = (score: number) => {
      if (score >= 80) return 'Optimal';
      if (score >= 60) return 'Favorable';
      if (score >= 40) return 'Marginal';
      return 'Not Recommended';
    };

    const getColor = (score: number) => {
      if (score >= 80) return 'text-emerald-400';
      if (score >= 60) return 'text-cyan-400';
      if (score >= 40) return 'text-amber-400';
      return 'text-rose-400';
    };

    return [
      {
        name: 'Running & Athletics',
        icon: Footprints,
        score: runScore,
        status: getStatus(runScore),
        color: getColor(runScore),
        reason:
          current.precipitation > 0
            ? 'Wet surfaces and active rainfall'
            : current.temperature > 26
            ? 'Elevated heat index; stay hydrated'
            : 'Favorable thermal balance and airway clarity',
      },
      {
        name: 'Cycling & Commute',
        icon: Bike,
        score: bikeScore,
        status: getStatus(bikeScore),
        color: getColor(bikeScore),
        reason:
          current.windSpeed > 25
            ? `Headwinds averaging ${formatSpeed(current.windSpeed, unit)}`
            : current.precipitation > 0
            ? 'Braking distance lengthened by precipitation'
            : 'Smooth tarmac and manageable atmospheric drag',
      },
      {
        name: 'Patio & Outdoor Dining',
        icon: UtensilsCrossed,
        score: dineScore,
        status: getStatus(dineScore),
        color: getColor(dineScore),
        reason:
          current.precipitation > 0
            ? 'Covered terrace or indoor dining recommended'
            : current.temperature < 16
            ? 'Brisk ambient temperature; outdoor heaters needed'
            : 'Pleasant ambient breezes and comfortable warmth',
      },
      {
        name: 'Night Sky & Stargazing',
        icon: Sparkle,
        score: starScore,
        status: getStatus(starScore),
        color: getColor(starScore),
        reason: current.isDay
          ? 'Sunlight obscuring stellar visibility (check after dusk)'
          : current.cloudCover > 50
          ? `${current.cloudCover}% cloud canopy obstructing astronomical observation`
          : 'High celestial clarity and deep nocturnal visibility',
      },
      {
        name: 'Automotive Travel',
        icon: Car,
        score: roadScore,
        status: getStatus(roadScore),
        color: getColor(roadScore),
        reason:
          current.weatherTheme === 'fog'
            ? 'Reduced sightlines; use low beam illumination'
            : current.precipitation > 0
            ? 'Standard wet weather deceleration required'
            : 'Optimal dry road traction across transit arteries',
      },
    ];
  };

  const activities = computeActivities();

  // Find the optimal 3-hour window
  const findBestWindow = () => {
    const next12Hours = hourly.slice(0, 12);
    let bestStartIndex = 0;
    let bestScore = -1;

    for (let i = 0; i <= next12Hours.length - 3; i++) {
      const windowItems = next12Hours.slice(i, i + 3);
      const avgRain =
        windowItems.reduce((acc, curr) => acc + curr.precipitationProbability, 0) / 3;
      const avgTemp =
        windowItems.reduce((acc, curr) => acc + curr.temperature, 0) / 3;
      const score = 100 - avgRain - Math.abs(avgTemp - 20) * 2;
      if (score > bestScore) {
        bestScore = score;
        bestStartIndex = i;
      }
    }

    const startItem = next12Hours[bestStartIndex];
    const endItem = next12Hours[Math.min(next12Hours.length - 1, bestStartIndex + 2)];

    return {
      window: `${startItem?.hour || 'Now'} – ${endItem?.hour || 'Later'}`,
      description: 'Minimum rain probability combined with optimal ambient temperature.',
    };
  };

  const bestWindow = findBestWindow();

  // What to wear logic
  const getClothingAdvice = () => {
    const temp = current.temperature;
    if (temp < 0) {
      return {
        label: 'Heavy Winter Insulation',
        detail: 'Thermal base layers, insulated down coat, gloves, and knit beanie.',
      };
    }
    if (temp < 12) {
      return {
        label: 'Structured Mid-Layering',
        detail: 'Wool sweater or fleece paired with a windbreaker or trench jacket.',
      };
    }
    if (temp < 20) {
      return {
        label: 'Light Transitional Layers',
        detail: 'Long-sleeve shirt or light cardigan; comfortable pants.',
      };
    }
    if (temp < 28) {
      return {
        label: 'Breathable Casual Wear',
        detail: 'Cotton/linen t-shirt, shorts or light trousers.',
      };
    }
    return {
      label: 'Ultra-Light Airy Attire',
      detail: 'Moisture-wicking, loose garments, wide-brim hat, and hydration carrier.',
    };
  };

  const clothing = getClothingAdvice();

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-cyan-400" />
          <h2 className="text-lg font-bold text-white tracking-tight">
            SkyCast Smart Activity Planner & Gear Advisory
          </h2>
        </div>
        <span className="text-xs text-slate-400 font-mono">
          Meteorological Suitability
        </span>
      </div>

      {/* Best Window Highlight Card */}
      <div className="rounded-2xl bg-gradient-to-r from-cyan-950/40 via-slate-900/60 to-slate-900/60 backdrop-blur-xl border border-cyan-800/40 p-5 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center shrink-0">
            <Clock className="w-6 h-6 text-cyan-400" />
          </div>
          <div>
            <p className="text-xs font-semibold text-cyan-300 uppercase tracking-wider">
              Recommended Outdoor Window
            </p>
            <p className="text-lg font-bold text-white font-mono">
              {bestWindow.window}
            </p>
            <p className="text-xs text-slate-400 mt-0.5">
              {bestWindow.description}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-cyan-300 bg-cyan-950/60 px-3 py-1.5 rounded-lg border border-cyan-800/60 self-start sm:self-auto">
          <Compass className="w-4 h-4" />
          <span>Optimal Target</span>
        </div>
      </div>

      {/* Activity Suitability Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {activities.map((act) => {
          const Icon = act.icon;
          return (
            <div
              key={act.name}
              className="rounded-xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 p-5 flex flex-col justify-between shadow-lg"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-lg bg-slate-850 text-slate-200">
                      <Icon className="w-4 h-4 text-cyan-400" />
                    </div>
                    <span className="text-sm font-bold text-white">
                      {act.name}
                    </span>
                  </div>
                  <span
                    className={`text-xs font-semibold px-2 py-0.5 rounded-md bg-slate-800/60 font-mono ${act.color}`}
                  >
                    {act.score}%
                  </span>
                </div>

                <div className="flex items-center gap-2 mb-2">
                  <span className={`text-xs font-bold ${act.color}`}>
                    {act.status}
                  </span>
                </div>
              </div>

              <div>
                {/* Score bar */}
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden mb-2.5">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      act.score >= 80
                        ? 'bg-emerald-400'
                        : act.score >= 60
                        ? 'bg-cyan-400'
                        : act.score >= 40
                        ? 'bg-amber-400'
                        : 'bg-rose-500'
                    }`}
                    style={{ width: `${act.score}%` }}
                  />
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  {act.reason}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Wardrobe & Gear Advisory Trio */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Attire Card */}
        <div className="rounded-xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 p-5 shadow-lg">
          <div className="flex items-center gap-2.5 mb-3">
            <Shirt className="w-5 h-5 text-sky-400" />
            <h3 className="text-sm font-bold text-white">Apparel Recommendation</h3>
          </div>
          <p className="text-sm font-semibold text-cyan-300 font-sans mb-1">
            {clothing.label}
          </p>
          <p className="text-xs text-slate-400 leading-relaxed">
            {clothing.detail}
          </p>
        </div>

        {/* Umbrella & Wet Weather Gear */}
        <div className="rounded-xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 p-5 shadow-lg">
          <div className="flex items-center gap-2.5 mb-3">
            <Umbrella className="w-5 h-5 text-cyan-400" />
            <h3 className="text-sm font-bold text-white">Precipitation Protection</h3>
          </div>
          <p className="text-sm font-semibold text-white mb-1">
            {current.precipitation > 0 || current.weatherTheme === 'rain'
              ? 'Umbrella Essential'
              : 'Umbrella Not Required'}
          </p>
          <p className="text-xs text-slate-400 leading-relaxed">
            {current.precipitation > 0
              ? 'Active rain observed. Keep compact umbrella or water-resistant shell accessible.'
              : 'Less than 15% probability of overhead precipitation during daylight hours.'}
          </p>
        </div>

        {/* Sunscreen & UV Eyewear */}
        <div className="rounded-xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 p-5 shadow-lg">
          <div className="flex items-center gap-2.5 mb-3">
            <Glasses className="w-5 h-5 text-amber-400" />
            <h3 className="text-sm font-bold text-white">Photoprotection (UV)</h3>
          </div>
          <p className="text-sm font-semibold text-white mb-1">
            {current.uvIndex >= 6
              ? 'SPF 30+ & Eyewear Mandatory'
              : current.uvIndex >= 3
              ? 'Moderate Protection Suggested'
              : 'Minimal Protection Needed'}
          </p>
          <p className="text-xs text-slate-400 leading-relaxed">
            {current.uvIndex >= 6
              ? `Current UV Index of ${current.uvIndex}. Direct dermal exposure can induce sunburn in under 25 minutes.`
              : `Current UV Index is ${current.uvIndex}. Ambient solar radiation remains within safe thresholds.`}
          </p>
        </div>
      </div>
    </div>
  );
};
