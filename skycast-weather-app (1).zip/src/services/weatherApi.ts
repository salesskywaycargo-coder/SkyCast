import {
  AirQualityData,
  CurrentWeatherData,
  DailyForecastItem,
  HourlyForecastItem,
  LocationData,
  WeatherData,
} from '../types/weather';
import {
  formatFullDay,
  formatShortDay,
  formatTimeHour,
  getAQIInfo,
  getWeatherConditionInfo,
} from './weatherUtils';

export const DEFAULT_CITIES: LocationData[] = [
  {
    id: 'tokyo-jp',
    name: 'Tokyo',
    country: 'Japan',
    countryCode: 'JP',
    admin1: 'Tokyo Prefecture',
    latitude: 35.6895,
    longitude: 139.6917,
    timezone: 'Asia/Tokyo',
  },
  {
    id: 'new-york-us',
    name: 'New York',
    country: 'United States',
    countryCode: 'US',
    admin1: 'New York',
    latitude: 40.7128,
    longitude: -74.006,
    timezone: 'America/New_York',
  },
  {
    id: 'london-gb',
    name: 'London',
    country: 'United Kingdom',
    countryCode: 'GB',
    admin1: 'England',
    latitude: 51.5074,
    longitude: -0.1278,
    timezone: 'Europe/London',
  },
  {
    id: 'paris-fr',
    name: 'Paris',
    country: 'France',
    countryCode: 'FR',
    admin1: 'Île-de-France',
    latitude: 48.8566,
    longitude: 2.3522,
    timezone: 'Europe/Paris',
  },
  {
    id: 'dubai-ae',
    name: 'Dubai',
    country: 'United Arab Emirates',
    countryCode: 'AE',
    admin1: 'Dubai',
    latitude: 25.2048,
    longitude: 55.2708,
    timezone: 'Asia/Dubai',
  },
  {
    id: 'sydney-au',
    name: 'Sydney',
    country: 'Australia',
    countryCode: 'AU',
    admin1: 'New South Wales',
    latitude: -33.8688,
    longitude: 151.2093,
    timezone: 'Australia/Sydney',
  },
  {
    id: 'san-francisco-us',
    name: 'San Francisco',
    country: 'United States',
    countryCode: 'US',
    admin1: 'California',
    latitude: 37.7749,
    longitude: -122.4194,
    timezone: 'America/Los_Angeles',
  },
  {
    id: 'singapore-sg',
    name: 'Singapore',
    country: 'Singapore',
    countryCode: 'SG',
    admin1: 'Singapore',
    latitude: 1.3521,
    longitude: 103.8198,
    timezone: 'Asia/Singapore',
  },
];

// Calculate approximate dew point using Magnus formula
function calculateDewPoint(temperature: number, humidity: number): number {
  const a = 17.27;
  const b = 237.7;
  const alpha = ((a * temperature) / (b + temperature)) + Math.log(Math.max(humidity, 1) / 100);
  return (b * alpha) / (a - alpha);
}

export async function searchCities(query: string): Promise<LocationData[]> {
  const trimmed = query.trim();
  if (trimmed.length < 2) return [];

  try {
    const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(
      trimmed
    )}&count=10&language=en&format=json`;
    const res = await fetch(url);
    if (!res.ok) throw new Error('Search failed');

    const data = await res.json();
    if (!data.results || !Array.isArray(data.results)) {
      return [];
    }

    return data.results.map((item: any) => ({
      id: `${item.id || item.latitude.toFixed(2)}-${item.longitude.toFixed(2)}`,
      name: item.name,
      country: item.country || '',
      countryCode: item.country_code || '',
      admin1: item.admin1 || '',
      latitude: item.latitude,
      longitude: item.longitude,
      timezone: item.timezone || 'auto',
    }));
  } catch (err) {
    console.warn('Geocoding search error:', err);
    // Filter from default cities on error/offline
    return DEFAULT_CITIES.filter(
      (c) =>
        c.name.toLowerCase().includes(trimmed.toLowerCase()) ||
        c.country.toLowerCase().includes(trimmed.toLowerCase())
    );
  }
}

export async function fetchWeatherForCoordinates(
  location: LocationData
): Promise<WeatherData> {
  const { latitude, longitude, timezone } = location;

  const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,rain,showers,snowfall,weather_code,cloud_cover,pressure_msl,surface_pressure,wind_speed_10m,wind_direction_10m,wind_gusts_10m,uv_index&hourly=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation_probability,precipitation,weather_code,cloud_cover,visibility,wind_speed_10m,wind_direction_10m,uv_index,is_day&daily=weather_code,temperature_2m_max,temperature_2m_min,apparent_temperature_max,apparent_temperature_min,sunrise,sunset,uv_index_max,precipitation_sum,precipitation_probability_max,wind_speed_10m_max,wind_direction_10m_dominant&timezone=${encodeURIComponent(
    timezone || 'auto'
  )}`;

  const airQualityUrl = `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${latitude}&longitude=${longitude}&current=european_aqi,us_aqi,pm10,pm2_5,carbon_monoxide,nitrogen_dioxide,sulphur_dioxide,ozone&timezone=${encodeURIComponent(
    timezone || 'auto'
  )}`;

  try {
    const [weatherRes, aqiRes] = await Promise.all([
      fetch(weatherUrl),
      fetch(airQualityUrl).catch(() => null),
    ]);

    if (!weatherRes.ok) {
      throw new Error(`Weather API error: ${weatherRes.status}`);
    }

    const weatherJson = await weatherRes.json();
    let aqiJson: any = null;
    if (aqiRes && aqiRes.ok) {
      try {
        aqiJson = await aqiRes.json();
      } catch {
        aqiJson = null;
      }
    }

    // Process Current Weather
    const currentRaw = weatherJson.current;
    const isDay = currentRaw.is_day === 1;
    const currentCond = getWeatherConditionInfo(currentRaw.weather_code, isDay);
    const dewPoint = calculateDewPoint(
      currentRaw.temperature_2m,
      currentRaw.relative_humidity_2m
    );

    // Estimate visibility in meters from hourly or default to 10km
    let currentVisibility = 10000;
    if (
      weatherJson.hourly &&
      weatherJson.hourly.visibility &&
      weatherJson.hourly.visibility.length > 0
    ) {
      currentVisibility = weatherJson.hourly.visibility[0] || 10000;
    }

    const current: CurrentWeatherData = {
      time: currentRaw.time,
      temperature: currentRaw.temperature_2m,
      apparentTemperature: currentRaw.apparent_temperature,
      relativeHumidity: currentRaw.relative_humidity_2m,
      weatherCode: currentRaw.weather_code,
      weatherDescription: currentCond.description,
      weatherTheme: currentCond.theme,
      isDay,
      precipitation: currentRaw.precipitation || 0,
      cloudCover: currentRaw.cloud_cover || 0,
      pressureMsl: currentRaw.pressure_msl || currentRaw.surface_pressure || 1013,
      windSpeed: currentRaw.wind_speed_10m || 0,
      windDirection: currentRaw.wind_direction_10m || 0,
      windGusts: currentRaw.wind_gusts_10m || currentRaw.wind_speed_10m || 0,
      uvIndex: currentRaw.uv_index || 0,
      visibility: currentVisibility,
      dewPoint: Math.round(dewPoint * 10) / 10,
    };

    // Process Hourly Forecast (Next 24 to 36 hours)
    const hourlyRaw = weatherJson.hourly;
    const hourly: HourlyForecastItem[] = [];

    if (hourlyRaw && hourlyRaw.time) {
      const nowTimeStr = currentRaw.time;
      let startIndex = hourlyRaw.time.findIndex(
        (t: string) => t >= nowTimeStr.slice(0, 13)
      );
      if (startIndex < 0) startIndex = 0;

      const endIndex = Math.min(startIndex + 36, hourlyRaw.time.length);

      for (let i = startIndex; i < endIndex; i++) {
        const itemTime = hourlyRaw.time[i];
        const itemIsDay = hourlyRaw.is_day ? hourlyRaw.is_day[i] === 1 : true;
        const itemCond = getWeatherConditionInfo(
          hourlyRaw.weather_code[i],
          itemIsDay
        );

        hourly.push({
          time: itemTime,
          hour: i === startIndex ? 'Now' : formatTimeHour(itemTime),
          timestamp: new Date(itemTime).getTime(),
          temperature: hourlyRaw.temperature_2m[i],
          apparentTemperature: hourlyRaw.apparent_temperature[i],
          humidity: hourlyRaw.relative_humidity_2m[i],
          precipitationProbability:
            hourlyRaw.precipitation_probability ? hourlyRaw.precipitation_probability[i] || 0 : 0,
          precipitation: hourlyRaw.precipitation ? hourlyRaw.precipitation[i] || 0 : 0,
          weatherCode: hourlyRaw.weather_code[i],
          weatherDescription: itemCond.description,
          weatherTheme: itemCond.theme,
          windSpeed: hourlyRaw.wind_speed_10m ? hourlyRaw.wind_speed_10m[i] || 0 : 0,
          windDirection: hourlyRaw.wind_direction_10m ? hourlyRaw.wind_direction_10m[i] || 0 : 0,
          uvIndex: hourlyRaw.uv_index ? hourlyRaw.uv_index[i] || 0 : 0,
          isDay: itemIsDay,
        });
      }
    }

    // Process Daily Forecast (7 to 10 days)
    const dailyRaw = weatherJson.daily;
    const daily: DailyForecastItem[] = [];

    if (dailyRaw && dailyRaw.time) {
      for (let i = 0; i < dailyRaw.time.length; i++) {
        const itemDate = dailyRaw.time[i];
        const dayCond = getWeatherConditionInfo(dailyRaw.weather_code[i], true);

        let dayName = formatShortDay(itemDate);
        if (i === 0) dayName = 'Today';
        else if (i === 1) dayName = 'Tomorrow';

        daily.push({
          date: itemDate,
          dayName,
          shortDate: formatShortDay(itemDate),
          weatherCode: dailyRaw.weather_code[i],
          weatherDescription: dayCond.description,
          weatherTheme: dayCond.theme,
          tempMax: dailyRaw.temperature_2m_max[i],
          tempMin: dailyRaw.temperature_2m_min[i],
          apparentTempMax: dailyRaw.apparent_temperature_max
            ? dailyRaw.apparent_temperature_max[i]
            : dailyRaw.temperature_2m_max[i],
          apparentTempMin: dailyRaw.apparent_temperature_min
            ? dailyRaw.apparent_temperature_min[i]
            : dailyRaw.temperature_2m_min[i],
          precipitationSum: dailyRaw.precipitation_sum
            ? dailyRaw.precipitation_sum[i] || 0
            : 0,
          precipitationProbabilityMax: dailyRaw.precipitation_probability_max
            ? dailyRaw.precipitation_probability_max[i] || 0
            : 0,
          uvIndexMax: dailyRaw.uv_index_max ? dailyRaw.uv_index_max[i] || 0 : 0,
          sunrise: dailyRaw.sunrise ? dailyRaw.sunrise[i] || '' : '',
          sunset: dailyRaw.sunset ? dailyRaw.sunset[i] || '' : '',
          windSpeedMax: dailyRaw.wind_speed_10m_max
            ? dailyRaw.wind_speed_10m_max[i] || 0
            : 0,
          windDirectionDominant: dailyRaw.wind_direction_10m_dominant
            ? dailyRaw.wind_direction_10m_dominant[i] || 0
            : 0,
        });
      }
    }

    // Process Air Quality
    let usAqi = 32;
    let europeanAqi = 24;
    let pm25 = 8.5;
    let pm10 = 16.2;
    let ozone = 45;
    let nitrogenDioxide = 18;
    let sulphurDioxide = 4.2;
    let carbonMonoxide = 280;

    if (aqiJson && aqiJson.current) {
      const a = aqiJson.current;
      usAqi = Math.round(a.us_aqi ?? 32);
      europeanAqi = Math.round(a.european_aqi ?? 25);
      pm25 = Math.round((a.pm2_5 ?? 8.5) * 10) / 10;
      pm10 = Math.round((a.pm10 ?? 16.2) * 10) / 10;
      ozone = Math.round(a.ozone ?? 45);
      nitrogenDioxide = Math.round(a.nitrogen_dioxide ?? 18);
      sulphurDioxide = Math.round(a.sulphur_dioxide ?? 4.2);
      carbonMonoxide = Math.round(a.carbon_monoxide ?? 280);
    }

    const aqiInfo = getAQIInfo(usAqi);

    const airQuality: AirQualityData = {
      usAqi,
      europeanAqi,
      pm25,
      pm10,
      ozone,
      nitrogenDioxide,
      sulphurDioxide,
      carbonMonoxide,
      statusLabel: aqiInfo.label,
      statusColor: aqiInfo.color,
      statusBg: aqiInfo.bg,
      healthAdvice: aqiInfo.advice,
    };

    return {
      location,
      current,
      hourly,
      daily,
      airQuality,
      lastUpdated: new Date().toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
      }),
    };
  } catch (error) {
    console.error('Failed to fetch real-time weather from Open-Meteo:', error);
    return getFallbackWeatherData(location);
  }
}

export function getFallbackWeatherData(location: LocationData): WeatherData {
  const isDay = true;
  return {
    location,
    current: {
      time: new Date().toISOString(),
      temperature: 21.5,
      apparentTemperature: 21.0,
      relativeHumidity: 58,
      weatherCode: 2,
      weatherDescription: 'Partly Cloudy',
      weatherTheme: 'cloudy',
      isDay,
      precipitation: 0,
      cloudCover: 35,
      pressureMsl: 1014,
      windSpeed: 14.5,
      windDirection: 210,
      windGusts: 22.0,
      uvIndex: 5,
      visibility: 10000,
      dewPoint: 12.8,
    },
    hourly: Array.from({ length: 24 }).map((_, i) => {
      const hourVal = (new Date().getHours() + i) % 24;
      const hourStr = `${hourVal === 0 ? '12' : hourVal > 12 ? hourVal - 12 : hourVal} ${
        hourVal >= 12 ? 'PM' : 'AM'
      }`;
      const temp = 18 + Math.sin(i / 3) * 5;
      return {
        time: new Date(Date.now() + i * 3600000).toISOString(),
        hour: i === 0 ? 'Now' : hourStr,
        timestamp: Date.now() + i * 3600000,
        temperature: Math.round(temp * 10) / 10,
        apparentTemperature: Math.round((temp - 0.5) * 10) / 10,
        humidity: Math.round(55 + Math.sin(i) * 10),
        precipitationProbability: Math.min(100, Math.max(0, Math.round(15 + Math.sin(i / 2) * 20))),
        precipitation: 0,
        weatherCode: i % 4 === 0 ? 1 : 2,
        weatherDescription: i % 4 === 0 ? 'Mainly Sunny' : 'Partly Cloudy',
        weatherTheme: 'cloudy',
        windSpeed: 12 + (i % 5),
        windDirection: 200 + (i * 5) % 60,
        uvIndex: hourVal >= 10 && hourVal <= 16 ? 5 : 0,
        isDay: hourVal >= 6 && hourVal <= 19,
      };
    }),
    daily: Array.from({ length: 7 }).map((_, i) => {
      const d = new Date(Date.now() + i * 86400000);
      return {
        date: d.toISOString().split('T')[0],
        dayName: i === 0 ? 'Today' : i === 1 ? 'Tomorrow' : formatShortDay(d.toISOString().split('T')[0]),
        shortDate: formatShortDay(d.toISOString().split('T')[0]),
        weatherCode: i % 3 === 0 ? 0 : 2,
        weatherDescription: i % 3 === 0 ? 'Clear Sky' : 'Partly Cloudy',
        weatherTheme: i % 3 === 0 ? 'clear-day' : 'cloudy',
        tempMax: 23 + (i % 3),
        tempMin: 15 - (i % 2),
        apparentTempMax: 23.5,
        apparentTempMin: 14.5,
        precipitationSum: i === 2 ? 2.4 : 0,
        precipitationProbabilityMax: i === 2 ? 45 : 10,
        uvIndexMax: 6,
        sunrise: '06:12',
        sunset: '18:45',
        windSpeedMax: 18.2,
        windDirectionDominant: 215,
      };
    }),
    airQuality: {
      usAqi: 35,
      europeanAqi: 22,
      pm25: 7.8,
      pm10: 15.4,
      ozone: 42,
      nitrogenDioxide: 16,
      sulphurDioxide: 3.8,
      carbonMonoxide: 260,
      statusLabel: 'Good',
      statusColor: 'text-emerald-400',
      statusBg: 'bg-emerald-500/10 border-emerald-500/30',
      healthAdvice: 'Air quality is ideal for outdoor activities and exercise.',
    },
    lastUpdated: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
  };
}
