import { WeatherTheme, WeatherUnit } from '../types/weather';

export function getWeatherConditionInfo(code: number, isDay: boolean = true): {
  description: string;
  theme: WeatherTheme;
  iconName: string;
} {
  switch (code) {
    case 0:
      return {
        description: isDay ? 'Clear Sky' : 'Clear Night',
        theme: isDay ? 'clear-day' : 'clear-night',
        iconName: isDay ? 'Sun' : 'Moon',
      };
    case 1:
      return {
        description: isDay ? 'Mainly Sunny' : 'Mainly Clear',
        theme: isDay ? 'clear-day' : 'clear-night',
        iconName: isDay ? 'SunMedium' : 'MoonStar',
      };
    case 2:
      return {
        description: 'Partly Cloudy',
        theme: 'cloudy',
        iconName: isDay ? 'CloudSun' : 'CloudMoon',
      };
    case 3:
      return {
        description: 'Overcast',
        theme: 'cloudy',
        iconName: 'Cloud',
      };
    case 45:
    case 48:
      return {
        description: 'Dense Fog',
        theme: 'fog',
        iconName: 'CloudFog',
      };
    case 51:
      return {
        description: 'Light Drizzle',
        theme: 'rain',
        iconName: 'CloudDrizzle',
      };
    case 53:
      return {
        description: 'Moderate Drizzle',
        theme: 'rain',
        iconName: 'CloudDrizzle',
      };
    case 55:
      return {
        description: 'Dense Drizzle',
        theme: 'rain',
        iconName: 'CloudRain',
      };
    case 56:
    case 57:
      return {
        description: 'Freezing Drizzle',
        theme: 'snow',
        iconName: 'CloudSnow',
      };
    case 61:
      return {
        description: 'Light Rain',
        theme: 'rain',
        iconName: 'CloudRain',
      };
    case 63:
      return {
        description: 'Moderate Rain',
        theme: 'rain',
        iconName: 'CloudRain',
      };
    case 65:
      return {
        description: 'Heavy Downpour',
        theme: 'rain',
        iconName: 'CloudRainWind',
      };
    case 66:
    case 67:
      return {
        description: 'Freezing Rain',
        theme: 'snow',
        iconName: 'CloudSnow',
      };
    case 71:
      return {
        description: 'Light Snowfall',
        theme: 'snow',
        iconName: 'CloudSnow',
      };
    case 73:
      return {
        description: 'Moderate Snowfall',
        theme: 'snow',
        iconName: 'CloudSnow',
      };
    case 75:
      return {
        description: 'Heavy Snowfall',
        theme: 'snow',
        iconName: 'Snowflake',
      };
    case 77:
      return {
        description: 'Snow Grains',
        theme: 'snow',
        iconName: 'Snowflake',
      };
    case 80:
      return {
        description: 'Light Rain Showers',
        theme: 'rain',
        iconName: 'CloudRain',
      };
    case 81:
      return {
        description: 'Showers',
        theme: 'rain',
        iconName: 'CloudRain',
      };
    case 82:
      return {
        description: 'Violent Showers',
        theme: 'rain',
        iconName: 'CloudRainWind',
      };
    case 85:
    case 86:
      return {
        description: 'Snow Showers',
        theme: 'snow',
        iconName: 'CloudSnow',
      };
    case 95:
      return {
        description: 'Thunderstorm',
        theme: 'thunder',
        iconName: 'CloudLightning',
      };
    case 96:
    case 99:
      return {
        description: 'Severe Thunderstorm',
        theme: 'thunder',
        iconName: 'CloudLightning',
      };
    default:
      return {
        description: 'Partly Cloudy',
        theme: 'cloudy',
        iconName: 'Cloud',
      };
  }
}

export function formatTemp(celsius: number, unit: WeatherUnit): string {
  if (unit === 'imperial') {
    const fahrenheit = (celsius * 9) / 5 + 32;
    return `${Math.round(fahrenheit)}°`;
  }
  return `${Math.round(celsius)}°`;
}

export function formatTempRaw(celsius: number, unit: WeatherUnit): number {
  if (unit === 'imperial') {
    return Math.round((celsius * 9) / 5 + 32);
  }
  return Math.round(celsius);
}

export function formatSpeed(kmh: number, unit: WeatherUnit): string {
  if (unit === 'imperial') {
    const mph = kmh * 0.621371;
    return `${Math.round(mph)} mph`;
  }
  return `${Math.round(kmh)} km/h`;
}

export function formatPrecipitation(mm: number, unit: WeatherUnit): string {
  if (unit === 'imperial') {
    const inches = mm * 0.0393701;
    return `${inches.toFixed(2)} in`;
  }
  return `${mm.toFixed(1)} mm`;
}

export function formatPressure(hpa: number, unit: WeatherUnit): string {
  if (unit === 'imperial') {
    const inHg = hpa * 0.02953;
    return `${inHg.toFixed(2)} inHg`;
  }
  return `${Math.round(hpa)} hPa`;
}

export function formatVisibility(meters: number, unit: WeatherUnit): string {
  if (unit === 'imperial') {
    const miles = (meters / 1000) * 0.621371;
    return `${miles.toFixed(1)} mi`;
  }
  const km = meters / 1000;
  return `${km.toFixed(1)} km`;
}

export function getWindDirectionCardinal(deg: number): string {
  const directions = [
    'N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE',
    'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW',
  ];
  const index = Math.round((deg % 360) / 22.5) % 16;
  return directions[index];
}

export function getUVDescription(uv: number): { label: string; color: string; advice: string } {
  if (uv <= 2) {
    return {
      label: 'Low',
      color: 'text-emerald-400',
      advice: 'Minimal sun protection needed. Safe for outdoor activities.',
    };
  }
  if (uv <= 5) {
    return {
      label: 'Moderate',
      color: 'text-yellow-400',
      advice: 'Wear sunglasses and apply SPF 30+ sunscreen if outside during midday.',
    };
  }
  if (uv <= 7) {
    return {
      label: 'High',
      color: 'text-orange-400',
      advice: 'Protection essential. Seek shade during peak midday hours.',
    };
  }
  if (uv <= 10) {
    return {
      label: 'Very High',
      color: 'text-rose-400',
      advice: 'Extra protection required. Avoid direct sun exposure between 10am - 4pm.',
    };
  }
  return {
    label: 'Extreme',
    color: 'text-purple-400',
    advice: 'Take all precautions. Unprotected skin can burn in minutes.',
  };
}

export function getAQIInfo(usAqi: number): {
  label: string;
  color: string;
  bg: string;
  advice: string;
} {
  if (usAqi <= 50) {
    return {
      label: 'Good',
      color: 'text-emerald-400',
      bg: 'bg-emerald-500/10 border-emerald-500/30',
      advice: 'Air quality is satisfactory and poses little or no risk to public health.',
    };
  }
  if (usAqi <= 100) {
    return {
      label: 'Moderate',
      color: 'text-yellow-400',
      bg: 'bg-yellow-500/10 border-yellow-500/30',
      advice: 'Acceptable quality. Sensitive individuals should consider reducing heavy outdoor exertion.',
    };
  }
  if (usAqi <= 150) {
    return {
      label: 'Unhealthy for Sensitive Groups',
      color: 'text-orange-400',
      bg: 'bg-orange-500/10 border-orange-500/30',
      advice: 'Members of sensitive groups may experience health effects. General public less likely affected.',
    };
  }
  if (usAqi <= 200) {
    return {
      label: 'Unhealthy',
      color: 'text-rose-400',
      bg: 'bg-rose-500/10 border-rose-500/30',
      advice: 'Everyone may begin to experience health effects; members of sensitive groups may experience more serious effects.',
    };
  }
  if (usAqi <= 300) {
    return {
      label: 'Very Unhealthy',
      color: 'text-purple-400',
      bg: 'bg-purple-500/10 border-purple-500/30',
      advice: 'Health alert: risk of health effects is increased for everyone in the population.',
    };
  }
  return {
    label: 'Hazardous',
    color: 'text-red-500',
    bg: 'bg-red-500/10 border-red-500/30',
    advice: 'Health warning of emergency conditions. The entire population is more likely to be affected.',
  };
}

export function formatTimeHour(isoString: string): string {
  try {
    const d = new Date(isoString);
    return d.toLocaleTimeString([], { hour: 'numeric', hour12: true });
  } catch {
    return isoString.slice(11, 16);
  }
}

export function formatShortDay(isoDate: string): string {
  try {
    const d = new Date(isoDate + 'T00:00:00');
    return d.toLocaleDateString([], { weekday: 'short' });
  } catch {
    return isoDate;
  }
}

export function formatFullDay(isoDate: string): string {
  try {
    const d = new Date(isoDate + 'T00:00:00');
    return d.toLocaleDateString([], { weekday: 'long', month: 'short', day: 'numeric' });
  } catch {
    return isoDate;
  }
}
